import React, { useRef, useState } from 'react';
import {
  Battery,
  Flashlight,
  Goal,
  Hand,
  Pause,
  Play,
  Radio,
  Settings as SettingsIcon,
  Skull,
  Video,
  Volume2,
} from 'lucide-react';
import { EndingSummary, HighScoreEntry, HudSnapshot, Settings } from '../types/game';

export const IS_TOUCH = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

// ================= OVERLAY VHS =================
export function VhsOverlay({ hud, intensity }: { hud: HudSnapshot | null; intensity: number }): React.JSX.Element {
  const inter = Math.min(1, (hud?.interference ?? 0.1) * intensity);
  const chase = hud?.chaseActive ?? false;
  const cam = hud?.camOn ?? false;
  return (
    <div className="pointer-events-none absolute inset-0 z-20 overflow-hidden">
      <div className="crt-scanlines absolute inset-0 opacity-70" style={{ opacity: 0.35 + intensity * 0.45 }} />
      <div className="vhs-grain absolute -inset-[8%] opacity-40" style={{ opacity: 0.25 + intensity * 0.35 }} />
      <div className="crt-vignette absolute inset-0" />
      <div className="vhs-tracking-bar absolute inset-x-0 h-10 bg-gradient-to-b from-transparent via-white/12 to-transparent" />
      {cam && <div className="nv-tint absolute inset-0" />}
      {/* interferencia extra */}
      {inter > 0.3 && (
        <>
          <div className="animate-glitch absolute inset-x-0 top-[30%] h-2 bg-cyan-300/10 mix-blend-screen" style={{ opacity: inter * 0.7 }} />
          <div className="animate-glitch absolute inset-x-0 top-[62%] h-4 bg-red-500/10 mix-blend-screen" style={{ opacity: inter * 0.8 }} />
        </>
      )}
      {hud?.dangerFlash && (
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(120,0,0,0)_30%,rgba(160,10,10,0.45)_100%)] animate-pulse" />
      )}
      {chase && <div className="danger-pulse absolute inset-0" />}
      {/* marcos de cámara */}
      {cam && (
        <div className="absolute inset-4 sm:inset-8 border-2 border-slate-200/30 rounded-sm">
          <div className="absolute -top-0.5 -left-0.5 h-5 w-5 border-t-4 border-l-4 border-slate-200/70" />
          <div className="absolute -top-0.5 -right-0.5 h-5 w-5 border-t-4 border-r-4 border-slate-200/70" />
          <div className="absolute -bottom-0.5 -left-0.5 h-5 w-5 border-b-4 border-l-4 border-slate-200/70" />
          <div className="absolute -bottom-0.5 -right-0.5 h-5 w-5 border-b-4 border-r-4 border-slate-200/70" />
        </div>
      )}
      <div className="reticle absolute h-1.5 w-1.5 rounded-full bg-white/50" />
    </div>
  );
}

// ================= HUD DE JUEGO =================
export function GameHud({ hud }: { hud: HudSnapshot }): React.JSX.Element {
  const radios = hud.radios;
  const checks: [string, boolean][] = [
    ['Encontrar la primera grabación', radios[0]],
    ['Encontrar la segunda grabación', radios[1]],
    ['Encontrar la tercera grabación', radios[2]],
    ['Encontrar la cuarta grabación', radios[3]],
    ['Encontrar la quinta grabación', radios[4]],
    ['Encontrar la sexta grabación', radios[5]],
    ['Ir al dormitorio', hud.casaReached],
    ['Dormir', false],
  ];
  return (
    <div className="pointer-events-none absolute inset-0 z-30 p-3 sm:p-5 flex flex-col justify-between">
      {/* superior */}
      <div className="flex items-start justify-between gap-3">
        <div className="bg-black/55 border border-white/10 rounded px-3 py-2">
          <div className="font-vhs text-lg sm:text-2xl leading-none text-zinc-100 tracking-widest animate-flicker">
            {hud.timestamp}
          </div>
          <div className={`mt-1 flex items-center gap-2 text-[11px] font-bold text-red-400`}>
            <span className={`h-2 w-2 rounded-full bg-red-500 animate-pulse`} />
            REC
          </div>
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className="bg-black/55 border border-white/10 rounded px-3 py-2 text-right">
            <div className="text-[10px] tracking-widest text-zinc-400">PUNTUACIÓN</div>
            <div className="font-vhs text-xl sm:text-2xl leading-none text-amber-200">{hud.score.toLocaleString()}</div>
          </div>
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1.5 rounded border px-2 py-1 text-[11px] font-bold ${hud.flashlightOn ? 'border-amber-300/50 text-amber-200 bg-amber-900/30' : 'border-white/10 text-zinc-500 bg-black/50'}`}>
              <Flashlight className="h-3.5 w-3.5" /> LUZ {hud.flashlightBattery}%
            </div>
            <div className={`flex items-center gap-1.5 rounded border px-2 py-1 text-[11px] font-bold ${hud.camOn ? 'border-slate-300/40 text-slate-200 bg-slate-900/40' : 'border-white/10 text-zinc-500 bg-black/50'}`}>
              <Video className="h-3.5 w-3.5" /> CÁMARA
            </div>
            <div className="flex items-center gap-1.5 rounded border border-white/10 bg-black/50 px-2 py-1 text-[11px] font-bold text-zinc-300">
              <Battery className="h-3.5 w-3.5" /> {hud.battery}%
            </div>
          </div>
        </div>
      </div>

      {/* objetivos (izquierda) */}
      <div className="max-w-[260px]">
        <div className="bg-black/55 border border-white/10 rounded px-3 py-2">
          <div className="mb-1 flex items-center gap-1.5 text-[10px] font-extrabold tracking-widest text-rose-300">
            <Goal className="h-3.5 w-3.5" /> OBJETIVOS
          </div>
          {checks.map(([label, done]) => (
            <label key={label} className="flex items-center gap-1.5 py-0.5 text-[11px] text-zinc-300">
              <span className={`flex h-3.5 w-3.5 items-center justify-center border text-[9px] ${done ? 'border-emerald-400 bg-emerald-500/30 text-emerald-200' : 'border-zinc-600 text-transparent'}`}>✓</span>
              <span className={done ? 'line-through text-zinc-500' : ''}>{label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* centro: prompt / mensaje / subtítulo */}
      <div className="absolute inset-x-0 top-[62%] flex flex-col items-center gap-2">
        {hud.message && (
          <div className="rounded border border-amber-300/40 bg-amber-950/70 px-3 py-1 text-xs font-extrabold tracking-widest text-amber-200">
            {hud.message}
          </div>
        )}
        {hud.prompt && (
          <div className="animate-pulse rounded border border-cyan-300/60 bg-cyan-950/75 px-4 py-1.5 text-xs font-extrabold tracking-widest text-cyan-100 sm:text-sm">
            {hud.prompt}
          </div>
        )}
        {hud.chaseActive && (
          <div className="rounded border border-red-500/60 bg-red-950/80 px-3 py-1 text-[11px] font-extrabold tracking-widest text-red-200 animate-pulse">
            ¡EL CAZADOR TE BUSCA! ESCÓNDETE — APAGA LA LINTERNA
          </div>
        )}
        {hud.subtitle && (
          <div className="max-w-lg rounded bg-black/85 px-4 py-2 text-center font-vhs text-xl leading-tight text-lime-100/95 sm:text-2xl">
            {hud.subtitle}
          </div>
        )}
      </div>

      {/* inferior: pistas de teclado */}
      {!IS_TOUCH && (
        <div className="self-start rounded bg-black/50 border border-white/10 px-2.5 py-1.5 text-[10px] font-semibold tracking-wider text-zinc-400">
          WASD moverse · SHIFT correr · F linterna · C cámara · E interactuar · ESC pausa
        </div>
      )}
    </div>
  );
}

// ================= MENÚS =================
function MenuShell({ children }: { children: React.ReactNode }): React.JSX.Element {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-black/60 p-4 backdrop-blur-[2px]">
      <div className="w-full max-w-2xl rounded-lg border border-white/20 bg-zinc-950/95 p-6 sm:p-8 shadow-[0_0_70px_rgba(0,0,0,0.9)]">
        {children}
      </div>
    </div>
  );
}

export function StartMenu(props: {
  bestScore: number;
  scores: HighScoreEntry[];
  onPlay: () => void;
  onOptions: () => void;
  onCredits: () => void;
}): React.JSX.Element {
  return (
    <MenuShell>
      <div className="flex items-center gap-2 text-[11px] font-bold tracking-[0.25em] text-red-400">
        <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
        CINTA 09 · 31 DE OCTUBRE DE 1993 · MAVI-CAM XP200
      </div>
      <h1 className="font-vhs mt-2 text-6xl leading-none text-white sm:text-7xl animate-flicker drop-shadow-[0_0_16px_rgba(255,255,255,0.2)]">
        SUEÑO VHS
      </h1>
      <div className="font-vhs text-3xl leading-none text-red-400/90 tracking-[0.3em]">NO DESPIERTES</div>
      <p className="mt-4 max-w-lg text-xs leading-relaxed text-zinc-400 sm:text-sm">
        Te despiertas en un bosque que no recuerdas, con una linterna y una vieja videocámara que
        <span className="text-green-300"> revela lo que la oscuridad esconde</span>. Encuentra tu casa,
        encuentra las <span className="text-amber-300">tres grabadoras de mamá</span> y duerme... si aún puedes.
      </p>

      <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-5 text-[10px]">
        {['EL ALTO', 'EL RASTRERO', 'EL DEFORME', 'EL CAZADOR', 'EL DEL ARMARIO'].map((m, i) => (
          <div key={m} className={`rounded border px-2 py-2 text-center font-extrabold tracking-wider ${i === 3 ? 'border-red-500/50 bg-red-950/40 text-red-300' : 'border-white/15 bg-zinc-900/60 text-zinc-300'}`}>
            {m}
          </div>
        ))}
      </div>

      <div className="mt-6 flex flex-col gap-2.5">
        <button onClick={props.onPlay} className="flex items-center justify-center gap-2 rounded bg-red-700 py-3 text-sm font-extrabold tracking-[0.25em] text-white transition hover:bg-red-600 active:scale-[0.98] cursor-pointer">
          <Play className="h-4 w-4" /> JUGAR
        </button>
        <div className="grid grid-cols-2 gap-2.5">
          <button onClick={props.onOptions} className="flex items-center justify-center gap-2 rounded border border-white/15 bg-black/60 py-2.5 text-xs font-bold tracking-[0.25em] text-zinc-300 transition hover:bg-zinc-900 cursor-pointer">
            <SettingsIcon className="h-4 w-4" /> OPCIONES
          </button>
          <button onClick={props.onCredits} className="flex items-center justify-center gap-2 rounded border border-white/15 bg-black/60 py-2.5 text-xs font-bold tracking-[0.25em] text-zinc-300 transition hover:bg-zinc-900 cursor-pointer">
            <Skull className="h-4 w-4" /> CRÉDITOS
          </button>
        </div>
      </div>

      <div className="mt-5 rounded border border-white/10 bg-black/50 p-3">
        <div className="mb-2 flex items-center justify-between text-[10px] font-extrabold tracking-widest text-zinc-400">
          <span>REGISTRO LOCAL</span>
          <span className="text-amber-300">MEJOR: {props.bestScore.toLocaleString()}</span>
        </div>
        <div className="space-y-1">
          {props.scores.slice(0, 4).map((s, i) => (
            <div key={s.id} className="flex items-center justify-between text-[11px] text-zinc-300">
              <span className="flex items-center gap-2">
                <span className="text-zinc-600">#{i + 1}</span>
                <span className="font-bold">{s.name}</span>
                <span className={`rounded px-1 py-0.5 text-[9px] font-extrabold ${s.ending === 'BUENO' ? 'bg-emerald-900/60 text-emerald-300' : 'bg-red-950/70 text-red-400'}`}>{s.ending}</span>
              </span>
              <span className="font-vhs text-base leading-none">{s.score.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </MenuShell>
  );
}

export function PauseMenu(props: {
  onResume: () => void;
  onRestart: () => void;
  onOptions: () => void;
  onMenu: () => void;
}): React.JSX.Element {
  return (
    <MenuShell>
      <div className="font-vhs text-5xl text-amber-300 animate-flicker">PAUSA</div>
      <div className="mt-1 text-xs tracking-[0.3em] text-zinc-400">LA CINTA SE DETIENE... EL BOSQUE NO.</div>
      <div className="mt-6 flex flex-col gap-2.5">
        <MenuBtn label="CONTINUAR" onClick={props.onResume} primary />
        <MenuBtn label="REINICIAR PARTIDA" onClick={props.onRestart} />
        <MenuBtn label="OPCIONES" onClick={props.onOptions} />
        <MenuBtn label="MENÚ PRINCIPAL" onClick={props.onMenu} />
      </div>
    </MenuShell>
  );
}

function MenuBtn({ label, onClick, primary }: { label: string; onClick: () => void; primary?: boolean }): React.JSX.Element {
  return (
    <button onClick={onClick} className={`rounded py-3 text-xs font-extrabold tracking-[0.3em] transition active:scale-[0.98] cursor-pointer ${primary ? 'bg-red-700 text-white hover:bg-red-600' : 'border border-white/15 bg-zinc-900 text-zinc-200 hover:bg-zinc-800'}`}>
      {label}
    </button>
  );
}

export function OptionsModal({ settings, onChange, onClose }: {
  settings: Settings;
  onChange: (s: Settings) => void;
  onClose: () => void;
}): React.JSX.Element {
  const up = (patch: Partial<Settings>): void => onChange({ ...settings, ...patch });
  return (
    <MenuShell>
      <div className="flex items-center justify-between">
        <div className="font-vhs text-4xl text-cyan-300">OPCIONES</div>
        <button onClick={onClose} className="rounded border border-white/20 px-3 py-1.5 text-xs font-bold text-zinc-300 hover:bg-zinc-800 cursor-pointer">VOLVER</button>
      </div>
      <div className="mt-5 space-y-5">
        <div>
          <div className="mb-2 text-[11px] font-extrabold tracking-widest text-zinc-400">CALIDAD GRÁFICA</div>
          <div className="grid grid-cols-3 gap-2">
            {(['low', 'medium', 'high'] as const).map((q) => (
              <button
                key={q}
                onClick={() => up({ quality: q })}
                className={`rounded border py-2 text-xs font-bold tracking-widest transition cursor-pointer ${settings.quality === q ? 'border-cyan-400 bg-cyan-900/40 text-cyan-200' : 'border-white/15 bg-zinc-900 text-zinc-400 hover:bg-zinc-800'}`}
              >
                {q === 'low' ? 'BAJA' : q === 'medium' ? 'MEDIA' : 'ALTA'}
              </button>
            ))}
          </div>
          <div className="mt-1 text-[10px] text-zinc-500">AFECTA A SOMBRAS, NIEBLA Y DENSIDAD DEL BOSQUE. “BAJA” RECOMENDADA EN MÓVILES.</div>
        </div>

        <Slider label="VOLUMEN" value={settings.volume} min={0} max={1} onChange={(v) => up({ volume: v })} icon={<Volume2 className="h-4 w-4" />} />
        <Slider label="SENSIBILIDAD DE CÁMARA" value={settings.sensitivity} min={0.3} max={2} onChange={(v) => up({ sensitivity: v })} icon={<Hand className="h-4 w-4" />} />
        <Slider label="INTENSIDAD VHS" value={settings.vhsIntensity} min={0.3} max={1.5} onChange={(v) => up({ vhsIntensity: v })} icon={<Video className="h-4 w-4" />} />

        <div>
          <div className="mb-2 text-[11px] font-extrabold tracking-widest text-zinc-400">NOMBRE DEL REGISTRO</div>
          <input
            value={settings.callsign}
            onChange={(e) => up({ callsign: e.target.value.toUpperCase().slice(0, 14) })}
            className="w-full rounded border border-white/20 bg-black/70 px-3 py-2 text-sm font-bold tracking-widest text-amber-200 outline-none"
          />
        </div>
      </div>
    </MenuShell>
  );
}

function Slider({ label, value, min, max, onChange, icon }: {
  label: string; value: number; min: number; max: number;
  onChange: (v: number) => void; icon?: React.ReactNode;
}): React.JSX.Element {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-[11px] font-extrabold tracking-widest text-zinc-400">
        <span className="flex items-center gap-1.5">{icon}{label}</span>
        <span className="text-zinc-200">{Math.round(value * 100)}%</span>
      </div>
      <input
        type="range" min={min} max={max} step={0.01} value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full accent-red-500"
      />
    </div>
  );
}

export function CreditsModal({ onClose }: { onClose: () => void }): React.JSX.Element {
  return (
    <MenuShell>
      <div className="flex items-center justify-between">
        <div className="font-vhs text-4xl text-violet-300">CRÉDITOS</div>
        <button onClick={onClose} className="rounded border border-white/20 px-3 py-1.5 text-xs font-bold text-zinc-300 hover:bg-zinc-800 cursor-pointer">VOLVER</button>
      </div>
      <div className="mt-4 space-y-3 text-xs leading-relaxed text-zinc-400">
        <p><span className="text-zinc-200 font-bold">SUEÑO VHS — NO DESPIERTES</span><br />Una grabación perdida de terror analógico en primera persona.</p>
        <p>Diseño de criaturas: EL ALTO · EL RASTRERO · EL DEFORME · EL CAZADOR · EL DEL ARMARIO.<br />
          Cada criatura posee anatomía, animación, voz e IA propias.</p>
        <p>El motor 3D utiliza WebGL/Three.js con geometría procedural, partículas y audio sintetizado en tiempo real mediante la Web Audio API.</p>
        <p className="text-zinc-500">Si escuchas risas en la distancia... no corras hacia ellas.</p>
        <p className="font-vhs text-xl text-red-400">REC · 1993</p>
      </div>
    </MenuShell>
  );
}

// ================= FINALES =================
export function EndingScreen(props: {
  summary: EndingSummary;
  scores: HighScoreEntry[];
  rank: number;
  isRecord: boolean;
  onRetry: () => void;
  onMenu: () => void;
}): React.JSX.Element {
  const { summary } = props;
  const good = summary.mode === 'good';
  const caught = summary.mode === 'caught';
  return (
    <div className={`absolute inset-0 z-40 flex items-center justify-center p-4 ${good ? 'fade-black bg-black' : 'bg-red-950/30'}`}>
      {!good && <div className="absolute inset-0 vhs-grain opacity-50" />}
      <div className={`relative w-full max-w-xl rounded-lg border p-6 sm:p-8 ${good ? 'border-white/10 bg-[#050505]' : 'border-red-500/50 bg-zinc-950/95'} text-center`}>
        {good ? (
          <>
            <div className="font-vhs text-5xl sm:text-6xl text-lime-100 animate-flicker">DESPIERTAS</div>
            <p className="mx-auto mt-3 max-w-md text-xs leading-relaxed text-zinc-400">
              La última grabación cesa. El armario permanece cerrado. Detrás de la ventana, el bosque
              suelta tu nombre por última vez. <span className="text-emerald-300">Escapaste del sueño.</span>
            </p>
          </>
        ) : (
          <>
            <div className="font-vhs text-5xl sm:text-6xl text-red-500 animate-glitch">GAME OVER</div>
            <div className="mt-2 text-[11px] font-extrabold tracking-[0.35em] text-red-300">
              {caught ? 'EL CAZADOR TE ENCONTRÓ' : 'NO ENCONTRASTE LAS TRES GRABACIONES'}
            </div>
            <p className="mx-auto mt-3 max-w-md text-xs leading-relaxed text-zinc-400">
              {caught
                ? 'Sus pasos dejaron de sonar mucho antes de alcanzarte.'
                : '«Hey... mamá ya no está.» El armario sigue abierto y la cinta sigue grabando.'}
            </p>
          </>
        )}

        <div className="mt-6 grid grid-cols-3 gap-2">
          <div className="rounded border border-white/10 bg-black/60 p-3">
            <div className="text-[9px] tracking-widest text-zinc-500">PUNTOS</div>
            <div className="font-vhs text-2xl text-amber-200">{summary.score.toLocaleString()}</div>
          </div>
          <div className="rounded border border-white/10 bg-black/60 p-3">
            <div className="text-[9px] tracking-widest text-zinc-500">GRABACIONES</div>
            <div className="font-vhs text-2xl text-emerald-300">{summary.radios}/3</div>
          </div>
          <div className="rounded border border-white/10 bg-black/60 p-3">
            <div className="text-[9px] tracking-widest text-zinc-500">TIEMPO</div>
            <div className="font-vhs text-2xl text-cyan-300">{summary.timeSec}s</div>
          </div>
        </div>

        {props.isRecord && (
          <div className="mt-3 rounded border border-amber-300/50 bg-amber-900/30 px-3 py-1.5 text-xs font-extrabold tracking-widest text-amber-200">
            ¡NUEVO RÉCORD LOCAL — PUESTO #{props.rank}!
          </div>
        )}

        <div className="mt-5 grid grid-cols-2 gap-2.5">
          <button onClick={props.onRetry} className="rounded bg-red-700 py-3 text-xs font-extrabold tracking-[0.3em] text-white transition hover:bg-red-600 active:scale-[0.98] cursor-pointer">
            REINTENTAR
          </button>
          <button onClick={props.onMenu} className="rounded border border-white/20 bg-zinc-900 py-3 text-xs font-extrabold tracking-[0.3em] text-zinc-200 transition hover:bg-zinc-800 active:scale-[0.98] cursor-pointer">
            MENÚ PRINCIPAL
          </button>
        </div>
      </div>
    </div>
  );
}

// ================= CONTROLES TÁCTILES =================
export function MobileControls(props: {
  onMove: (x: number, y: number) => void;
  onLook: (dx: number, dy: number) => void;
  onRun: (v: boolean) => void;
  onCrouch: (v: boolean) => void;
  onFlash: () => void;
  onCam: () => void;
  onInteract: () => void;
  onPause: () => void;
}): React.JSX.Element {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const knobRef = useRef<HTMLDivElement | null>(null);
  const joyId = useRef<number | null>(null);
  const lookId = useRef<number | null>(null);
  const lookLast = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [runOn, setRunOn] = useState(false);
  const [crouchOn, setCrouchOn] = useState(false);

  const moveKnob = (dx: number, dy: number): void => {
    const k = knobRef.current;
    if (k) k.style.transform = `translate(${dx * 34}px, ${dy * 34}px)`;
  };

  const joyDown = (e: React.PointerEvent): void => {
    joyId.current = e.pointerId;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    joyMove(e);
  };
  const joyMove = (e: React.PointerEvent): void => {
    if (joyId.current !== e.pointerId || !baseRef.current) return;
    const r = baseRef.current.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let dx = (e.clientX - cx) / (r.width / 2);
    let dy = (e.clientY - cy) / (r.height / 2);
    const l = Math.hypot(dx, dy);
    if (l > 1) { dx /= l; dy /= l; }
    moveKnob(dx, dy);
    props.onMove(dx, dy);
  };
  const joyUp = (e: React.PointerEvent): void => {
    if (joyId.current !== e.pointerId) return;
    joyId.current = null;
    moveKnob(0, 0);
    props.onMove(0, 0);
  };

  const lookDown = (e: React.PointerEvent): void => {
    if (lookId.current !== null) return;
    lookId.current = e.pointerId;
    lookLast.current = { x: e.clientX, y: e.clientY };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const lookMove = (e: React.PointerEvent): void => {
    if (lookId.current !== e.pointerId) return;
    const dx = e.clientX - lookLast.current.x;
    const dy = e.clientY - lookLast.current.y;
    lookLast.current = { x: e.clientX, y: e.clientY };
    props.onLook(dx * 2.2, dy * 2.2);
  };
  const lookUp = (e: React.PointerEvent): void => {
    if (lookId.current === e.pointerId) lookId.current = null;
  };

  return (
    <>
      {/* zona de mirada (mitad derecha) */}
      <div
        className="absolute inset-y-0 right-0 w-1/2 z-30"
        onPointerDown={lookDown}
        onPointerMove={lookMove}
        onPointerUp={lookUp}
        onPointerCancel={lookUp}
        onLostPointerCapture={lookUp}
      />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-40 flex items-end justify-between p-4 pb-5">
        {/* joystick */}
        <div
          ref={baseRef}
          className="pointer-events-auto relative h-28 w-28 rounded-full border-2 border-white/25 bg-black/45"
          onPointerDown={joyDown}
          onPointerMove={joyMove}
          onPointerUp={joyUp}
          onPointerCancel={joyUp}
        onLostPointerCapture={joyUp}
        >
          <div ref={knobRef} className="absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/40 bg-zinc-700/80" />
        </div>

        {/* botones de acción */}
        <div className="pointer-events-auto grid grid-cols-2 gap-2">
          <TouchBtn icon={<Flashlight className="h-5 w-5" />} label="LUZ" onPress={props.onFlash} />
          <TouchBtn icon={<Video className="h-5 w-5" />} label="CAM" onPress={props.onCam} />
          <TouchBtn
            icon={<RunIcon />}
            label={runOn ? 'CORRER·ON' : 'CORRER'}
            active={runOn}
            onPress={() => { const v = !runOn; setRunOn(v); props.onRun(v); }}
          />
          <TouchBtn icon={<Hand className="h-5 w-5" />} label="USAR" onPress={props.onInteract} accent />
          <TouchBtn icon={<span className="text-lg leading-none">⌄</span>} label={crouchOn ? 'AGACHADO' : 'AGACHARSE'} active={crouchOn} onPress={() => { const v=!crouchOn; setCrouchOn(v); props.onCrouch(v); }} />
        </div>
      </div>
      <button
        onClick={props.onPause}
        className="absolute right-3 top-20 z-40 flex h-10 w-10 items-center justify-center rounded-full border border-white/25 bg-black/60 text-zinc-200 cursor-pointer"
        aria-label="Pausa"
      >
        <Pause className="h-5 w-5" />
      </button>
    </>
  );
}

function TouchBtn({ icon, label, onPress, active, accent }: {
  icon: React.ReactNode; label: string; onPress: () => void; active?: boolean; accent?: boolean;
}): React.JSX.Element {
  return (
    <button
      onPointerDown={(e) => { e.preventDefault(); onPress(); }}
      className={`flex h-14 w-14 flex-col items-center justify-center rounded-xl border text-[8px] font-extrabold tracking-wider transition active:scale-90 cursor-pointer ${
        accent
          ? 'border-cyan-400/60 bg-cyan-950/70 text-cyan-200'
          : active
          ? 'border-amber-400/70 bg-amber-900/60 text-amber-200'
          : 'border-white/25 bg-black/55 text-zinc-300'
      }`}
    >
      {icon}
      <span className="mt-1">{label}</span>
    </button>
  );
}

function RunIcon(): React.JSX.Element {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 17v5" /><path d="M13.83 20.85a2 2 0 0 0 1.93.08l4.5-2.25" /><path d="m8.7 6.3 3.3 2-3.3 2.5" /><circle cx="16.5" cy="5.5" r="2" /><path d="m9 14 2.06 4.06" /><path d="m13 9 2.4 2.4c.6.6 1.6.9 2.5.6" />
    </svg>
  );
}

// icono de radio usado por accesibilidad en HUD (no obligatorio)
export function RadioIcon(): React.JSX.Element {
  return <Radio className="h-3.5 w-3.5" />;
}

export function BatteryIcon({ level }: { level: number }): React.JSX.Element {
  return (
    <span className="relative h-3.5 w-6 rounded-[3px] border border-current">
      <span className="absolute inset-[2px]" style={{ width: `${Math.max(4, level)}%`, background: 'currentColor' }} />
    </span>
  );
}
