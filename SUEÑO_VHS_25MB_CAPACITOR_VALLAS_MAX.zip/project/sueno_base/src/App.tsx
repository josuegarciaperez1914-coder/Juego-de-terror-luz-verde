import { useCallback, useEffect, useRef, useState } from 'react';
import { vhsAudio } from './audio/vhsAudio';
import {
  CreditsModal,
  EndingScreen,
  GameHud,
  IS_TOUCH,
  MobileControls,
  OptionsModal,
  PauseMenu,
  StartMenu,
  VhsOverlay,
} from './components/UI';
import { GameEngine } from './game/engine';
import { EndingSummary, GamePhase, HighScoreEntry, HudSnapshot, Settings } from './types/game';
import {
  addScore,
  clearRun,
  loadScores,
  loadSettings,
  saveSettings,
} from './utils/highScores';

const INITIAL_HUD: HudSnapshot = {
  timestamp: 'OCT. 31 1993   00:00:00',
  battery: 100,
  flashlightBattery: 100,
  flashlightOn: false,
  camOn: false,
  chaseActive: false,
  score: 0,
  prompt: null,
  subtitle: null,
  radios: [false, false, false, false, false, false],
  casaReached: false,
  dangerFlash: false,
  interference: 0.1,
  message: null,
};

export function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [phase, setPhase] = useState<GamePhase>('menu');
  const phaseRef = useRef<GamePhase>('menu');
  const optionsFromRef = useRef<'menu' | 'paused'>('menu');

  const [settings, setSettings] = useState<Settings>(() => loadSettings());
  const [scores, setScores] = useState<HighScoreEntry[]>(() => loadScores());
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [ending, setEnding] = useState<EndingSummary | null>(null);
  const [endingMeta, setEndingMeta] = useState<{ rank: number; isRecord: boolean }>({ rank: 99, isRecord: false });

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  // ---------- crear motor una sola vez ----------
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;
    const st = loadSettings();
    const engine = new GameEngine(container, st, {
      onHud: (h) => setHud(h),
      onMessage: () => { /* ya visible vía hud.message */ },
      onPauseRequest: () => { /* manejado por keyboard */ },
      onSaveRun: () => { /* Sin checkpoints: cada partida empieza desde cero. */ },
      onEnding: (sum) => {
        const mapped = sum.mode === 'good' ? 'BUENO' as const : sum.mode === 'caught' ? 'CAPTURADO' as const : 'MALO' as const;
        const res = addScore({
          name: st.callsign || 'OPERADOR-93',
          score: sum.score,
          radios: sum.radios,
          ending: mapped,
          timeSec: sum.timeSec,
        });
        setScores(res.scores);
        setEndingMeta({ rank: res.rank, isRecord: res.isRecord });
        setEnding(sum);
        clearRun();
        setHasSave(false);
        setPhase(sum.mode === 'good' ? 'good-ending' : 'bad-ending');
      },
    });
    engineRef.current = engine;
    return () => {
      engineRef.current = null;
      engine.dispose();
    };
  }, []);

  // ---------- teclado global ----------
  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) return;
      const engine = engineRef.current;
      if (!engine) return;
      if (e.code === 'KeyF') engine.toggleFlashlight();
      else if (e.code === 'KeyC') engine.toggleCam();
      else if (e.code === 'KeyE' || e.code === 'Space') {
        if (phaseRef.current === 'playing') { e.preventDefault(); engine.interact(); }
      } else if (e.code === 'Escape') {
        if (phaseRef.current === 'playing') {
          engine.pause();
          setPhase('paused');
        } else if (phaseRef.current === 'paused') {
          engine.resume();
          setPhase('playing');
        } else if (phaseRef.current === 'options') {
          setPhase(optionsFromRef.current);
        } else if (phaseRef.current === 'credits') {
          setPhase('menu');
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ---------- pointer lock ----------
  useEffect(() => {
    const onLock = (): void => {
      const engine = engineRef.current;
      if (!document.pointerLockElement && engine && engine.phase === 'playing' && !IS_TOUCH) {
        engine.pause();
        setPhase('paused');
      }
    };
    document.addEventListener('pointerlockchange', onLock);
    return () => document.removeEventListener('pointerlockchange', onLock);
  }, []);

  const handleCanvasClick = useCallback((): void => {
    if (phaseRef.current === 'playing' && !IS_TOUCH) {
      engineRef.current?.requestPointerLock();
    }
  }, []);

  // ---------- acciones ----------
  const applyAndSave = useCallback((s: Settings): void => {
    setSettings(s);
    saveSettings(s);
    vhsAudio.setVolume(s.volume);
    engineRef.current?.applySettings(s);
  }, []);

  const startNew = useCallback((): void => {
    vhsAudio.unlock();
    clearRun();
    setEnding(null);
    setPhase('playing');
    engineRef.current?.startRun();
    engineRef.current?.requestPointerLock();
  }, []);

  const toMenu = useCallback((): void => {
    engineRef.current?.stopAll();
    setPhase('menu');
  }, []);

  const openOptions = useCallback((from: 'menu' | 'paused'): void => {
    optionsFromRef.current = from;
    setPhase('options');
  }, []);

  const bestScore = scores[0]?.score ?? 0;

  return (
    <div className="relative h-full w-full overflow-hidden bg-black">
      {/* Capa 3D */}
      <div ref={mountRef} className="absolute inset-0 z-10" onClick={handleCanvasClick} />

      {/* Overlays VHS */}
      <VhsOverlay hud={phase === 'playing' || phase === 'paused' ? hud : null} intensity={settings.vhsIntensity} />

      {/* HUD de partida */}
      {phase === 'playing' && <GameHud hud={hud} />}

      {/* Controles táctiles */}
      {phase === 'playing' && IS_TOUCH && (
        <MobileControls
          onMove={(x, y) => engineRef.current?.giveMobileMove(x, y)}
          onLook={(dx, dy) => engineRef.current?.giveLook(dx, dy)}
          onRun={(v) => engineRef.current?.giveMobileRun(v)}
          onCrouch={(v) => engineRef.current?.giveMobileCrouch(v)}
          onFlash={() => engineRef.current?.toggleFlashlight()}
          onCam={() => engineRef.current?.toggleCam()}
          onInteract={() => engineRef.current?.interact()}
          onPause={() => {
            engineRef.current?.pause();
            setPhase('paused');
          }}
        />
      )}

      {/* Menús */}
      {phase === 'menu' && (
        <StartMenu
          bestScore={bestScore}
          scores={scores}
          onPlay={startNew}
          onOptions={() => openOptions('menu')}
          onCredits={() => setPhase('credits')}
        />
      )}

      {phase === 'paused' && (
        <PauseMenu
          onResume={() => {
            engineRef.current?.resume();
            setPhase('playing');
            engineRef.current?.requestPointerLock();
          }}
          onRestart={startNew}
          onOptions={() => openOptions('paused')}
          onMenu={toMenu}
        />
      )}

      {phase === 'options' && (
        <OptionsModal
          settings={settings}
          onChange={applyAndSave}
          onClose={() => setPhase(optionsFromRef.current)}
        />
      )}

      {phase === 'credits' && <CreditsModal onClose={() => setPhase('menu')} />}

      {(phase === 'good-ending' || phase === 'bad-ending') && ending && (
        <EndingScreen
          summary={ending}
          scores={scores}
          rank={endingMeta.rank}
          isRecord={endingMeta.isRecord}
          onRetry={startNew}
          onMenu={toMenu}
        />
      )}
    </div>
  );
}

export default App;
