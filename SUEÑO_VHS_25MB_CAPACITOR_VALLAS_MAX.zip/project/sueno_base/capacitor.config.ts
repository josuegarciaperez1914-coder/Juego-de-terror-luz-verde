import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.suenovhs.game',
  appName: 'SUEÑO VHS',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
