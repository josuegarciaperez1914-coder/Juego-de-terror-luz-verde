# SUEÑO VHS — NO DESPIERTES

Base del proyecto preservada: React + Vite + Three.js.

## Cambios de esta revisión

- Corregidos los ejes del movimiento del jugador para que avanzar/retroceder coincidan con la dirección real de la cámara.
- Reinicio del estado de carrera táctil al iniciar una partida.
- Reforzada la captura y liberación de puntero en joystick y zona de cámara táctil.
- Ampliado el terreno jugable y el límite del bosque; aumentada la población instanciada de árboles, rocas y arbustos según calidad.
- Aumentada la distancia de cámara y suavizada la niebla para recuperar visibilidad en el bosque extendido.
- Mejorado el alcance y la potencia de la linterna.
- El Cazador despierta desde una posición fija y se desplaza hacia el ruido: ya no aparece teletransportado junto al jugador.
- Los tres monstruos del bosque pueden alertar al Cazador y sus desplazamientos respetan las colisiones del escenario.
- Añadidos dedos largos al Alto, garras al Rastrero y zarpas al Cazador; ensanchada la silueta de la cabeza del Alto.
- Sustituidos los modelos visuales de radio por grabadoras portátiles de casete con ventana, carretes, rejilla y botones.
- Cambiado el lenguaje visible de objetivos y finales a grabaciones/casetes; REC permanece visible durante la partida.
- Sustituido el tinte verde de cámara por un tratamiento frío y desaturado.

## Ejecución

Requiere Node.js. Instalar dependencias con `npm install` y ejecutar `npm run dev`.

Nota: en este entorno no fue posible completar la instalación de dependencias desde npm, por lo que se verificó la sintaxis TypeScript/TSX y comprobaciones estáticas, pero no se pudo ejecutar un build Vite ni probar el juego en un dispositivo Android real.
