import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const loader = new GLTFLoader();

export async function loadVisualModel(url: string, parent: THREE.Object3D, maxHeight: number, yOffset = 0): Promise<THREE.AnimationMixer | null> {
  try {
    const gltf = await loader.loadAsync(url);
    const root = gltf.scene;
    root.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.isMesh) {
        mesh.castShadow = false;
        mesh.receiveShadow = false;
        if (Array.isArray(mesh.material)) mesh.material.forEach((m) => { m.needsUpdate = true; });
        else if (mesh.material) mesh.material.needsUpdate = true;
      }
    });
    const box = new THREE.Box3().setFromObject(root);
    const size = box.getSize(new THREE.Vector3());
    if (size.y > 0) {
      const scale = maxHeight / size.y;
      root.scale.setScalar(scale);
      const scaledBox = new THREE.Box3().setFromObject(root);
      root.position.y += yOffset - scaledBox.min.y;
    }
    parent.add(root);
    if (gltf.animations.length) {
      const mixer = new THREE.AnimationMixer(root);
      gltf.animations.forEach((clip) => mixer.clipAction(clip).play());
      return mixer;
    }
  } catch (err) {
    console.warn(`[SUEÑO VHS] No se pudo cargar ${url}`, err);
  }
  return null;
}
