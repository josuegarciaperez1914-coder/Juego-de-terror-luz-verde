import * as THREE from 'three';
import { vhsAudio } from '../audio/vhsAudio';
import { MonsterKind } from '../types/game';

export interface MonsterCtx {
  playerPos: THREE.Vector3;
  playerRunning: boolean;
  flashlightOn: boolean;
  camOn: boolean;
  camForward: THREE.Vector3;
  los: (ax: number, az: number, bx: number, bz: number) => boolean;
  resolveMove: (from: THREE.Vector3, desired: THREE.Vector3) => THREE.Vector3;
  alert: (kind: MonsterKind, pos: THREE.Vector3) => void;
  onCaught: () => void;
  onStep: (dist: number) => void;
  onSurvive: () => void;
}

interface Part {
  mesh: THREE.Mesh;
  normal: THREE.Material;
  reveal: THREE.Material;
}

type PartsBag = { parts: Part[]; group: THREE.Group; head: THREE.Group; mouth: THREE.Mesh; eyes: THREE.Mesh[]; arms: THREE.Group[]; legs: THREE.Group[] };

const DARK = 0x050507;
const BONE = 0x8f8778;

function addPart(parent: THREE.Object3D, geo: THREE.BufferGeometry, x: number, y: number, z: number, parts: Part[], dark = DARK, reveal = BONE, rot?: THREE.Euler): THREE.Mesh {
  const normal = new THREE.MeshStandardMaterial({ color: dark, roughness: 0.96, metalness: 0.02 });
  const revealMat = new THREE.MeshStandardMaterial({ color: reveal, roughness: 0.85, emissive: 0x2a2620, emissiveIntensity: 0.35 });
  const mesh = new THREE.Mesh(geo, normal);
  mesh.position.set(x, y, z);
  if (rot) mesh.rotation.copy(rot);
  parent.add(mesh);
  parts.push({ mesh, normal, reveal: revealMat });
  return mesh;
}

function addEye(parent: THREE.Object3D, x: number, y: number, z: number, color: number, size = 0.035): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.SphereGeometry(size, 8, 8), new THREE.MeshBasicMaterial({ color }));
  m.position.set(x, y, z);
  parent.add(m);
  return m;
}

// ---------------- LOS CONSTRUCTORES ----------------

function buildAlto(): PartsBag {
  const group = new THREE.Group();
  const parts: Part[] = [];
  const eyes: THREE.Mesh[] = [];
  const arms: THREE.Group[] = [];
  const legs: THREE.Group[] = [];

  const torso = addPart(group, new THREE.CylinderGeometry(0.16, 0.22, 1.5, 7), 0, 2.05, 0, parts);
  torso.scale.x = 0.75;
  const neck = addPart(group, new THREE.CylinderGeometry(0.05, 0.08, 0.55, 6), 0, 2.98, 0, parts);
  neck.rotation.x = 0.12;

  const head = new THREE.Group();
  head.position.set(0, 3.32, 0.02);
  const skull = addPart(head, new THREE.SphereGeometry(0.17, 10, 10), 0, 0, 0, parts);
  skull.scale.set(1.55, 0.62, 0.82);
  const jaw = addPart(head, new THREE.BoxGeometry(0.09, 0.16, 0.1), 0, -0.2, 0.05, parts);
  jaw.scale.set(1, 1, 0.8);
  eyes.push(addEye(head, -0.105, 0.025, 0.12, 0xdfe9f2, 0.032));
  eyes.push(addEye(head, 0.105, 0.025, 0.12, 0xdfe9f2, 0.032));
  // sonrisa macabra (oculta)
  const mouthMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.035, 0.02), mouthMat);
  mouth.position.set(0, -0.1, 0.12);
  mouth.visible = false;
  head.add(mouth);
  parts.push({ mesh: mouth, normal: mouthMat, reveal: mouthMat });
  group.add(head);

  for (const sx of [-1, 1]) {
    const leg = new THREE.Group();
    leg.position.set(sx * 0.12, 1.32, 0);
    addPart(leg, new THREE.CylinderGeometry(0.045, 0.06, 1.32, 6), 0, -0.66, 0, parts);
    group.add(leg);
    legs.push(leg);

    const arm = new THREE.Group();
    arm.position.set(sx * 0.24, 2.66, 0);
    addPart(arm, new THREE.CylinderGeometry(0.035, 0.05, 1.5, 6), 0, -0.75, 0, parts, DARK, BONE, new THREE.Euler(0, 0, sx * 0.08));
    addPart(arm, new THREE.ConeGeometry(0.05, 0.22, 5), 0, -1.58, 0, parts, DARK, BONE, new THREE.Euler(Math.PI, 0, 0));
    // Dedos largos y separados: la silueta deja de parecer una simple varilla.
    for (let f = -1; f <= 1; f++) {
      const finger = addPart(arm, new THREE.CylinderGeometry(0.012, 0.022, 0.34, 5), f * 0.045, -1.78, 0.035, parts);
      finger.rotation.z = -f * 0.22;
      addPart(arm, new THREE.ConeGeometry(0.014, 0.09, 5), f * 0.045, -1.98, 0.035, parts, DARK, BONE, new THREE.Euler(Math.PI, 0, -f * 0.22));
    }
    group.add(arm);
    arms.push(arm);
  }
  return { parts, group, head, mouth, eyes, arms, legs };
}

function buildRastrero(): PartsBag {
  const group = new THREE.Group();
  const parts: Part[] = [];
  const eyes: THREE.Mesh[] = [];
  const arms: THREE.Group[] = [];
  const legs: THREE.Group[] = [];

  const bod = addPart(group, new THREE.SphereGeometry(0.42, 9, 7), 0, 0.55, 0, parts);
  bod.scale.set(0.85, 0.62, 1.5);
  const tail = addPart(group, new THREE.ConeGeometry(0.16, 0.7, 6), 0, 0.5, -0.85, parts, DARK, BONE, new THREE.Euler(Math.PI / 2 + 0.3, 0, 0));

  const head = new THREE.Group();
  head.position.set(0, 0.72, 0.72);
  const skull = addPart(head, new THREE.SphereGeometry(0.2, 9, 8), 0, 0, 0, parts);
  skull.scale.set(0.8, 0.9, 1.15);
  addPart(head, new THREE.ConeGeometry(0.12, 0.3, 5), 0, -0.1, 0.18, parts, DARK, BONE, new THREE.Euler(Math.PI / 2, 0, 0));
  eyes.push(addEye(head, -0.09, 0.06, 0.16, 0xff3333, 0.03));
  eyes.push(addEye(head, 0.09, 0.06, 0.16, 0xff3333, 0.03));
  const mouthMat = new THREE.MeshBasicMaterial({ color: 0xfff1d0 });
  const mouth = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.16, 4), mouthMat);
  mouth.position.set(0, -0.02, 0.22);
  mouth.rotation.x = Math.PI / 2;
  mouth.visible = false;
  head.add(mouth);
  parts.push({ mesh: mouth, normal: mouthMat, reveal: mouthMat });
  group.add(head);

  const limbPos: [number, number, number][] = [
    [-0.3, 0.5, 0.4], [0.3, 0.5, 0.4], [-0.32, 0.48, -0.42], [0.32, 0.48, -0.42],
  ];
  limbPos.forEach(([lx, ly, lz], i) => {
    const limb = new THREE.Group();
    limb.position.set(lx, ly, lz);
    const seg = addPart(limb, new THREE.CylinderGeometry(0.035, 0.06, 1.05, 5), 0, -0.4, 0, parts, DARK, BONE, new THREE.Euler(0.7, 0, lx > 0 ? -0.5 : 0.5));
    seg.position.y = -0.28;
    for (let claw = -1; claw <= 1; claw++) {
      addPart(limb, new THREE.ConeGeometry(0.025, 0.22, 5), claw * 0.055, -0.88, 0.08, parts, DARK, BONE, new THREE.Euler(Math.PI / 2, 0, claw * 0.2));
    }
    group.add(limb);
    if (i < 2) arms.push(limb); else legs.push(limb);
  });
  head.position.y = 0.72; void tail;
  return { parts, group, head, mouth, eyes, arms, legs };
}

function buildDeforme(): PartsBag {
  const group = new THREE.Group();
  const parts: Part[] = [];
  const eyes: THREE.Mesh[] = [];
  const arms: THREE.Group[] = [];
  const legs: THREE.Group[] = [];

  const torso = addPart(group, new THREE.CylinderGeometry(0.14, 0.24, 1.35, 7), 0, 1.55, 0, parts);
  torso.rotation.z = 0.22;
  addPart(group, new THREE.SphereGeometry(0.22, 8, 7), -0.14, 2.15, 0.02, parts); // joroba

  const head = new THREE.Group();
  head.position.set(0.06, 2.42, 0.06);
  head.rotation.z = 0.5;
  const skull = addPart(head, new THREE.SphereGeometry(0.16, 10, 9), 0, 0, 0, parts);
  skull.scale.set(0.8, 1.7, 0.85);
  eyes.push(addEye(head, -0.045, 0.1, 0.13, 0xf7f1e3, 0.032));
  eyes.push(addEye(head, 0.075, -0.02, 0.12, 0xf7f1e3, 0.05)); // ojos desiguales
  const mouthMat = new THREE.MeshBasicMaterial({ color: 0xfef3c7 });
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.05, 0.02), mouthMat);
  mouth.position.set(0.0, -0.14, 0.12);
  mouth.rotation.z = 0.25;
  mouth.visible = false;
  head.add(mouth);
  parts.push({ mesh: mouth, normal: mouthMat, reveal: mouthMat });
  group.add(head);

  // brazo larguísimo izquierdo y brazo corto derecho
  const armL = new THREE.Group();
  armL.position.set(-0.2, 2.1, 0);
  addPart(armL, new THREE.CylinderGeometry(0.04, 0.05, 1.95, 6), 0, -0.95, 0, parts, DARK, BONE, new THREE.Euler(0, 0, 0.12));
  addPart(armL, new THREE.ConeGeometry(0.06, 0.3, 5), 0.12, -2.0, 0, parts, DARK, BONE, new THREE.Euler(Math.PI, 0, 0.2));
  group.add(armL);
  arms.push(armL);
  const armR = new THREE.Group();
  armR.position.set(0.2, 2.05, 0);
  addPart(armR, new THREE.CylinderGeometry(0.05, 0.07, 0.7, 6), 0, -0.35, 0, parts, DARK, BONE, new THREE.Euler(0, 0, -0.35));
  group.add(armR);
  arms.push(armR);

  for (const [sx, len] of [[-1, 1.35], [1, 1.1]] as const) {
    const leg = new THREE.Group();
    leg.position.set(sx * 0.11, 1.05, 0);
    addPart(leg, new THREE.CylinderGeometry(0.05, 0.07, len, 6), 0, -len / 2, 0, parts);
    group.add(leg);
    legs.push(leg);
  }
  return { parts, group, head, mouth, eyes, arms, legs };
}

function buildCazador(): PartsBag {
  const group = new THREE.Group();
  const parts: Part[] = [];
  const eyes: THREE.Mesh[] = [];
  const arms: THREE.Group[] = [];
  const legs: THREE.Group[] = [];

  const torso = addPart(group, new THREE.CylinderGeometry(0.3, 0.2, 1.6, 8), 0, 1.9, 0, parts, 0x030304, 0x4a4038);
  torso.rotation.x = 0.22; // encorvado
  const shoulders = addPart(group, new THREE.BoxGeometry(0.95, 0.22, 0.34), 0, 2.62, 0.06, parts, 0x030304, 0x4a4038);

  const head = new THREE.Group();
  head.position.set(0, 2.86, 0.2);
  const skull = addPart(head, new THREE.SphereGeometry(0.19, 10, 9), 0, 0, 0, parts, 0x030304, 0x4a4038);
  skull.scale.set(0.9, 1.1, 1.05);
  // cresta dorsal en la cabeza
  addPart(head, new THREE.ConeGeometry(0.09, 0.42, 5), 0, 0.22, -0.1, parts, 0x030304, 0x4a4038, new THREE.Euler(-0.6, 0, 0));
  eyes.push(addEye(head, -0.08, 0.02, 0.15, 0xff1a1a, 0.045));
  eyes.push(addEye(head, 0.08, 0.02, 0.15, 0xff1a1a, 0.045));
  const mouthMat = new THREE.MeshBasicMaterial({ color: 0xfde68a });
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.09, 0.02), mouthMat);
  mouth.position.set(0, -0.13, 0.15);
  mouth.visible = false;
  head.add(mouth);
  parts.push({ mesh: mouth, normal: mouthMat, reveal: mouthMat });
  group.add(head);

  for (const sx of [-1, 1]) {
    const arm = new THREE.Group();
    arm.position.set(sx * 0.5, 2.55, 0.05);
    addPart(arm, new THREE.CylinderGeometry(0.055, 0.08, 1.55, 6), 0, -0.72, 0, parts, 0x030304, 0x4a4038, new THREE.Euler(0.25, 0, sx * 0.12));
    addPart(arm, new THREE.ConeGeometry(0.07, 0.45, 5), sx * 0.06, -1.62, 0.06, parts, 0x030304, 0x4a4038, new THREE.Euler(Math.PI - 0.2, 0, sx * 0.1));
    for (let claw = -1; claw <= 1; claw++) {
      const talon = addPart(arm, new THREE.ConeGeometry(0.025, 0.32, 5), sx * 0.06 + claw * 0.07, -1.86, 0.12, parts, 0x030304, 0x4a4038, new THREE.Euler(Math.PI - 0.1, 0, claw * 0.18));
      talon.scale.set(1, 1.15, 1);
    }
    group.add(arm);
    arms.push(arm);

    const leg = new THREE.Group();
    leg.position.set(sx * 0.18, 1.15, 0);
    addPart(leg, new THREE.CylinderGeometry(0.06, 0.09, 1.2, 6), 0, -0.6, 0, parts, 0x030304, 0x4a4038);
    group.add(leg);
    legs.push(leg);
  }
  void shoulders;
  return { parts, group, head, mouth, eyes, arms, legs };
}

// ---------------- CLASE BASE (criaturas del bosque) ----------------

type WanderState = 'idle' | 'wander' | 'notice' | 'laugh' | 'flee' | 'dormant';

export class ForestMonster {
  public kind: 'alto' | 'rastrero' | 'deforme';
  public group: THREE.Group;
  public state: WanderState = 'wander';
  public revealed = false;

  protected bag: PartsBag;
  private spawns: THREE.Vector3[];
  private homeIndex = 0;
  private wanderTarget = new THREE.Vector3();
  private stateTime = 0;
  private respawnTimer = 0;
  private noticeDelay = 0;
  private speedCur = 0;
  private twitchTimer = 0;
  private yawWalk = 0;
  private alertRolled = false;

  // personalidad
  private pDetect: number;
  private pAlertChance: number;
  private pFleeSpeed: number;
  private pWalkSpeed: number;
  private pLaughGain: number;

  constructor(kind: 'alto' | 'rastrero' | 'deforme', spawns: THREE.Vector3[]) {
    this.kind = kind;
    this.bag = kind === 'alto' ? buildAlto() : kind === 'rastrero' ? buildRastrero() : buildDeforme();
    this.group = this.bag.group;
    this.spawns = spawns;
    this.pDetect = kind === 'alto' ? 17 : kind === 'rastrero' ? 8 : 12;
    this.pAlertChance = kind === 'alto' ? 0.45 : kind === 'rastrero' ? 0.3 : 0.85;
    this.pFleeSpeed = kind === 'alto' ? 9 : kind === 'rastrero' ? 10.5 : 8;
    this.pWalkSpeed = kind === 'alto' ? 0.7 : kind === 'rastrero' ? 1.7 : 1.1;
    this.pLaughGain = kind === 'rastrero' ? 0.7 : kind === 'deforme' ? 1.1 : 1;
    this.respawn();
  }

  private respawn(): void {
    this.homeIndex = Math.floor(Math.random() * this.spawns.length);
    const p = this.spawns[this.homeIndex];
    this.group.position.set(p.x + (Math.random() - 0.5) * 4, 0, p.z + (Math.random() - 0.5) * 4);
    this.group.rotation.y = Math.random() * Math.PI * 2;
    this.group.visible = true;
    this.state = 'wander';
    this.stateTime = 0;
    this.alertRolled = false;
    this.bag.mouth.visible = false;
    this.speedCur = 0;
  }

  reset(): void {
    this.respawn();
    this.setRevealed(false);
  }

  setRevealed(v: boolean): void {
    if (v === this.revealed) return;
    this.revealed = v;
    for (const p of this.bag.parts) {
      p.mesh.material = v ? p.reveal : p.normal;
    }
  }

  private lookAtPlayer(target: THREE.Vector3, dt: number, rate = 5): void {
    const dx = target.x - this.group.position.x;
    const dz = target.z - this.group.position.z;
    const wantYaw = Math.atan2(dx, dz);
    let cur = this.group.rotation.y;
    let diff = wantYaw - cur;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.group.rotation.y = cur + diff * Math.min(1, rate * dt);
  }

  update(dt: number, t: number, ctx: MonsterCtx): void {
    if (this.state === 'dormant') {
      this.respawnTimer = Math.max(0, this.respawnTimer - dt);
      if (this.respawnTimer === 0) this.respawn();
      return;
    }
    const gx = this.group.position.x, gz = this.group.position.z;
    const dx = ctx.playerPos.x - gx, dz = ctx.playerPos.z - gz;
    const dist = Math.hypot(dx, dz);
    const losOk = dist < 1.5 ? true : ctx.los(gx, gz, ctx.playerPos.x, ctx.playerPos.z);

    // detección
    if ((this.state === 'wander' || this.state === 'idle') && losOk) {
      let seen = dist < this.pDetect;
      // linterna enfocada aumenta rango
      if (!seen && ctx.flashlightOn && dist < this.pDetect + 9) {
        const dot = (-dx / dist) * ctx.camForward.x + (-dz / dist) * ctx.camForward.z;
        if (dot > 0.9) seen = true;
      }
      // cámara reinada en la criatura
      if (!seen && ctx.camOn && dist < 30) {
        const dot = (-dx / dist) * ctx.camForward.x + (-dz / dist) * ctx.camForward.z;
        if (dot > 0.93) { seen = true; this.noticeDelay = 0.2; }
      }
      // ruido al correr
      if (!seen && ctx.playerRunning && dist < 6) seen = true;

      if (seen) {
        this.state = 'notice';
        this.stateTime = 0;
        this.noticeDelay = this.kind === 'rastrero' ? 0.7 : this.kind === 'deforme' ? 1.2 : 2.2;
      }
    }

    switch (this.state) {
      case 'wander': {
        this.stateTime += dt;
        const wx = this.wanderTarget.x, wz = this.wanderTarget.z;
        const wdx = wx - gx, wdz = wz - gz;
        const wdist = Math.hypot(wdx, wdz);
        if (wdist < 1 || this.stateTime > 8) {
          const home = this.spawns[this.homeIndex];
          const a = Math.random() * Math.PI * 2;
          const r = 2 + Math.random() * 7;
          this.wanderTarget.set(home.x + Math.cos(a) * r, 0, home.z + Math.sin(a) * r);
          this.stateTime = 0;
          this.yawWalk = Math.atan2(this.wanderTarget.x - gx, this.wanderTarget.z - gz);
        }
        this.yawWalk = Math.atan2(wdx, wdz);
        this.group.rotation.y = THREE.MathUtils.lerp(this.group.rotation.y, this.yawWalk, Math.min(1, 2 * dt));
        this.speedCur = THREE.MathUtils.lerp(this.speedCur, this.pWalkSpeed, dt * 2);
        const wanderNext = this.group.position.clone();
        wanderNext.x += Math.sin(this.group.rotation.y) * this.speedCur * dt;
        wanderNext.z += Math.cos(this.group.rotation.y) * this.speedCur * dt;
        const wanderResolved = ctx.resolveMove(this.group.position, wanderNext);
        this.group.position.set(wanderResolved.x, this.group.position.y, wanderResolved.z);
        break;
      }
      case 'notice': {
        this.speedCur = 0;
        this.lookAtPlayer(ctx.playerPos, dt, this.kind === 'rastrero' ? 3 : 1.8);
        this.stateTime += dt;
        // sonrisa gradual
        this.bag.mouth.visible = true;
        const s = Math.min(1, this.stateTime / Math.max(0.3, this.noticeDelay));
        this.bag.mouth.scale.set(1, 0.3 + s * 1.4, 1);
        if (this.stateTime >= this.noticeDelay) {
          this.state = 'laugh';
          this.stateTime = 0;
          this.alertRolled = Math.random() < this.pAlertChance;
          vhsAudio.laugh(this.kind, this.pLaughGain);
        }
        break;
      }
      case 'laugh': {
        this.stateTime += dt;
        this.lookAtPlayer(ctx.playerPos, dt, 4);
        this.bag.mouth.scale.set(1 + Math.sin(this.stateTime * 30) * 0.3, 1.8, 1);
        if (this.stateTime > (this.kind === 'rastrero' ? 0.8 : 1.4)) {
          if (this.alertRolled) {
            ctx.alert(this.kind, this.group.position.clone());
          }
          this.state = 'flee';
          this.stateTime = 0;
        }
        break;
      }
      case 'flee': {
        this.stateTime += dt;
        const awayYaw = Math.atan2(-dx, -dz) + Math.sin(this.stateTime * 3) * 0.3;
        let cur = this.group.rotation.y;
        let diff = awayYaw - cur;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        this.group.rotation.y = cur + diff * Math.min(1, 6 * dt);
        this.speedCur = THREE.MathUtils.lerp(this.speedCur, this.pFleeSpeed, dt * 5);
        const fleeNext = this.group.position.clone();
        fleeNext.x += Math.sin(this.group.rotation.y) * this.speedCur * dt;
        fleeNext.z += Math.cos(this.group.rotation.y) * this.speedCur * dt;
        const fleeResolved = ctx.resolveMove(this.group.position, fleeNext);
        this.group.position.set(fleeResolved.x, this.group.position.y, fleeResolved.z);
        this.bag.mouth.visible = this.stateTime < 0.6;
        const movedFar = dist > 34;
        if (movedFar || this.stateTime > 5.5) {
          if (this.alertRolled && this.kind !== 'deforme') {
            ctx.alert(this.kind, this.group.position.clone());
          }
          this.state = 'dormant';
          this.group.visible = false;
          this.respawnTimer = 22 + Math.random() * 20;
        }
        break;
      }
      default:
        break;
    }

    this.animate(dt, t, dist);
  }

  protected animate(dt: number, t: number, dist: number): void {
    const moving = this.speedCur > 0.1;
    const freq = this.kind === 'rastrero' ? 11 : 7;
    const amp = moving ? (this.kind === 'rastrero' ? 0.55 : 0.4) : 0.05;
    const ph = t * freq * (this.speedCur > this.pWalkSpeed * 1.2 ? 1.7 : 1);

    if (this.kind === 'alto') {
      this.bag.legs.forEach((l, i) => { l.rotation.x = Math.sin(ph + i * Math.PI) * amp; });
      this.bag.arms.forEach((a, i) => { a.rotation.x = Math.sin(ph + i * Math.PI) * amp * 0.5 + 0.05; });
      this.group.scale.y = 1 + Math.sin(t * 1.2) * 0.008;
      // cabeza girando hacia el jugador si lo observa
      if (this.state === 'notice' || this.state === 'laugh') {
        this.bag.head.rotation.z = Math.sin(t * 0.9) * 0.16;
        this.bag.head.rotation.x = 0.1;
      }
    } else if (this.kind === 'rastrero') {
      const limbs = [...this.bag.arms, ...this.bag.legs];
      limbs.forEach((l, i) => { l.rotation.x = Math.sin(ph + (i % 2) * Math.PI + (i > 1 ? Math.PI * 0.5 : 0)) * amp * 0.9; });
      this.bag.head.rotation.x = this.state === 'wander' ? 0.1 : -0.25;
      this.group.position.y = moving ? Math.abs(Math.sin(ph * 0.5)) * 0.06 : 0;
    } else {
      // deforme: tics violentos
      this.twitchTimer -= dt;
      if (this.twitchTimer <= 0) {
        this.twitchTimer = 0.28 + Math.random() * 0.5;
        this.bag.head.rotation.z = 0.5 + (Math.random() - 0.5) * 0.9;
        this.bag.head.rotation.y = (Math.random() - 0.5) * 0.9;
      }
      this.bag.head.rotation.x = -0.1 + Math.sin(t * 1.7) * 0.25;
      this.bag.legs[0].rotation.x = Math.sin(ph) * amp * (moving ? 1.15 : 0.5);
      this.bag.legs[1].rotation.x = Math.sin(ph * 0.8 + 1.2) * amp * 0.8;
      this.bag.arms[0].rotation.x = Math.sin(t * 0.8) * 0.12;
    }
    void dist;
  }
}

// ---------------- EL CAZADOR ----------------

type CazState = 'dormant' | 'investigate' | 'search' | 'pursue' | 'lose';

export class CazadorMonster {
  public group: THREE.Group;
  public state: CazState = 'dormant';
  public revealed = false;

  private bag = buildCazador();
  private target = new THREE.Vector3();
  private lastSeen = new THREE.Vector3();
  private searchNodes: THREE.Vector3[] = [];
  private losLost = 0;
  private stateTime = 0;
  private yawWalk = 0;
  private stepTimer = 0;
  private insideHouseCheck: (p: THREE.Vector3) => boolean;
  private readonly home = new THREE.Vector3(88, 0, -92);

  constructor(insideHouseCheck: (p: THREE.Vector3) => boolean) {
    this.group = this.bag.group;
    this.group.visible = false;
    this.insideHouseCheck = insideHouseCheck;
  }

  reset(): void {
    this.state = 'dormant';
    this.group.position.copy(this.home);
    this.group.rotation.set(0, 0, 0);
    this.group.visible = false;
    this.losLost = 0;
    this.stateTime = 0;
    this.stepTimer = 0;
    this.searchNodes = [];
    this.setRevealed(false);
  }

  setRevealed(v: boolean): void {
    if (v === this.revealed) return;
    this.revealed = v;
    for (const p of this.bag.parts) p.mesh.material = v ? p.reveal : p.normal;
  }

  isHunting(): boolean {
    return this.state === 'investigate' || this.state === 'search' || this.state === 'pursue';
  }

  alert(pos: THREE.Vector3, _playerPos: THREE.Vector3): void {
    this.target.copy(pos);
    if (this.state === 'dormant') {
      // El Cazador despierta desde su zona fija; nunca aparece teletransportado junto al jugador.
      this.group.visible = true;
      vhsAudio.growl();
    }
    this.state = 'investigate';
    this.stateTime = 0;
  }

  update(dt: number, t: number, ctx: MonsterCtx): void {
    if (this.state === 'dormant') return;
    const gx = this.group.position.x, gz = this.group.position.z;
    const dx = ctx.playerPos.x - gx, dz = ctx.playerPos.z - gz;
    const dist = Math.hypot(dx, dz);
    const losOk = ctx.los(gx, gz, ctx.playerPos.x, ctx.playerPos.z);
    const playerIndoors = this.insideHouseCheck(ctx.playerPos);

    // ¿ve al jugador?
    let senses = false;
    if (!playerIndoors || dist < 3.4) {
      if (losOk) {
        if (dist < 13) senses = true;
        else if (ctx.flashlightOn && dist < 21) {
          const dot = (-dx / dist) * ctx.camForward.x + (-dz / dist) * ctx.camForward.z;
          if (dot > 0.55) senses = true;
        }
        if (ctx.playerRunning && dist < 10) senses = true;
      } else if (ctx.playerRunning && dist < 5.2) senses = true;
    }

    if (this.state !== 'pursue' && senses) {
      this.state = 'pursue';
      this.stateTime = 0;
      vhsAudio.growl();
    }

    let speed = 0;
    switch (this.state) {
      case 'investigate': {
        this.target.y = 0;
        const tx = this.target.x - gx, tz = this.target.z - gz;
        const td = Math.hypot(tx, tz);
        speed = 3.3;
        if (td < 1.2) {
          this.state = 'search';
          this.stateTime = 0;
          this.searchNodes = [];
          for (let i = 0; i < 3; i++) {
            const a = Math.random() * Math.PI * 2;
            this.searchNodes.push(new THREE.Vector3(
              this.target.x + Math.cos(a) * (4 + i * 2.2), 0,
              this.target.z + Math.sin(a) * (4 + i * 2.2)
            ));
          }
        } else {
          this.yawWalk = Math.atan2(tx, tz);
        }
        break;
      }
      case 'search': {
        this.stateTime += dt;
        if (this.searchNodes.length === 0) {
          // se rinde
          this.state = 'dormant';
          this.group.visible = false;
          if (playerIndoors || dist > 14) ctx.onSurvive();
          return;
        }
        const node = this.searchNodes[0];
        const nd = Math.hypot(node.x - gx, node.z - gz);
        speed = 2.4;
        this.yawWalk = Math.atan2(node.x - gx, node.z - gz);
        if (nd < 1.0) this.searchNodes.shift();
        // mirada barrida
        this.bag.head.rotation.y = Math.sin(t * 1.6) * 0.9;
        break;
      }
      case 'pursue': {
        speed = 6.7;
        this.lastSeen.copy(ctx.playerPos);
        this.yawWalk = Math.atan2(dx, dz);
        const blockedLos = !losOk && !senses;
        if (blockedLos || playerIndoors) {
          this.losLost += dt;
        } else {
          this.losLost = 0;
        }
        if (this.losLost > 3.2) {
          this.state = 'search';
          this.target.copy(this.lastSeen);
          this.searchNodes = [];
          for (let i = 0; i < 2; i++) {
            const a = Math.random() * Math.PI * 2;
            this.searchNodes.push(new THREE.Vector3(
              this.lastSeen.x + Math.cos(a) * (3.5 + i * 2.5), 0,
              this.lastSeen.z + Math.sin(a) * (3.5 + i * 2.5)
            ));
          }
          this.losLost = 0;
          ctx.onSurvive();
        }
        if (dist < 1.5 && losOk) {
          ctx.onCaught();
        }
        break;
      }
      default:
        break;
    }

    if (speed > 0) {
      this.group.rotation.y = THREE.MathUtils.lerp(this.group.rotation.y, this.yawWalk, Math.min(1, 6 * dt));
      const desired = this.group.position.clone();
      desired.x += Math.sin(this.group.rotation.y) * speed * dt;
      desired.z += Math.cos(this.group.rotation.y) * speed * dt;
      const moved = ctx.resolveMove(this.group.position, desired);
      this.group.position.set(moved.x, 0, moved.z);
      // pasos pesados
      this.stepTimer -= dt;
      if (this.stepTimer <= 0) {
        this.stepTimer = this.state === 'pursue' ? 0.38 : 0.62;
        ctx.onStep(dist);
      }
    }

    const ph = t * (this.state === 'pursue' ? 9.5 : 6);
    const amp = speed > 0 ? 0.45 : 0.04;
    this.bag.legs.forEach((l, i) => { l.rotation.x = Math.sin(ph + i * Math.PI) * amp; });
    this.bag.arms.forEach((a, i) => {
      a.rotation.x = Math.sin(ph + i * Math.PI) * amp * 0.8 + (this.state === 'pursue' ? 0.5 : 0.12);
    });
    this.bag.mouth.visible = this.state === 'pursue';
    if (this.state !== 'search') this.bag.head.rotation.y = Math.sin(t * 0.8) * 0.14;
    if (this.state === 'pursue') {
      this.bag.head.rotation.x = -0.12;
      this.bag.mouth.scale.set(1, 1 + Math.sin(t * 22) * 0.4, 1);
    }
    // sacudida roja de ojos
    const eyeMat = this.bag.eyes[0].material as THREE.MeshBasicMaterial;
    const inten = this.state === 'pursue' ? 1 : 0.6;
    eyeMat.color.setHex(inten > 0.8 ? 0xff2020 : 0xff5050);
    void dt;
  }
}

// ---------------- MOTHER (MICKEY POSEÍDO) ----------------
// La entidad usa exclusivamente el modelo mother..glb cargado por GameEngine.
// No existe un monstruo humanoide genérico del armario.
export class MotherEntity {
  public group: THREE.Group;
  public emerged = false;
  private targetPos = new THREE.Vector3();
  private speed = 1.05;
  private arriveCb: (() => void) | null = null;
  private elapsed = 0;

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'Mother_Possessed_Mickey';
    this.group.visible = false;
  }

  reset(): void {
    this.emerged = false;
    this.group.visible = false;
    this.elapsed = 0;
    this.arriveCb = null;
  }

  place(pos: THREE.Vector3, faceYaw: number): void {
    this.group.position.copy(pos);
    this.group.rotation.set(0, faceYaw, 0);
  }

  emerge(target: THREE.Vector3, onArrive: () => void): void {
    this.emerged = true;
    this.group.visible = true;
    this.targetPos.copy(target);
    this.arriveCb = onArrive;
    this.elapsed = 0;
  }

  update(dt: number, t: number): void {
    if (!this.emerged) return;
    this.elapsed += dt;
    const dx = this.targetPos.x - this.group.position.x;
    const dz = this.targetPos.z - this.group.position.z;
    const dist = Math.hypot(dx, dz);
    if (dist > 0.85) {
      const yaw = Math.atan2(dx, dz);
      this.group.rotation.y = THREE.MathUtils.lerp(this.group.rotation.y, yaw, Math.min(1, 3 * dt));
      const step = Math.floor(this.elapsed * 2.2) % 2 === 0 ? 1 : 0.15;
      this.group.position.x += Math.sin(this.group.rotation.y) * this.speed * step * dt;
      this.group.position.z += Math.cos(this.group.rotation.y) * this.speed * step * dt;
    } else if (this.arriveCb) {
      const cb = this.arriveCb;
      this.arriveCb = null;
      cb();
    }
    this.group.position.y = Math.sin(t * 2.1) * 0.025;
    this.group.rotation.z = Math.sin(t * 0.65) * 0.025;
  }
}
