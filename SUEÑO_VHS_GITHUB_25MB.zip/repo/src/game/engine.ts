import * as THREE from 'three';
import { vhsAudio } from '../audio/vhsAudio';
import { CazadorMonster, ClosetMonster, ForestMonster } from './monsters';
import { PlayerController } from './player';
import { buildWorld, collideMove, hasLos, WorldRefs } from './world';
import { EndingSummary, HudSnapshot, Settings } from '../types/game';
import { loadVisualModel } from './modelLoader';

export interface EngineCallbacks {
  onHud: (hud: HudSnapshot) => void;
  onEnding: (sum: EndingSummary) => void;
  onMessage: (text: string) => void;
  onPauseRequest: () => void;
  onSaveRun: (radios: [boolean, boolean, boolean, boolean, boolean, boolean], score: number) => void;
}

const RADIO_TEXTS: [string, string, string, string, string, string] = [
  'YA VEN A DORMIR.',
  'YA ES HORA DE DORMIR.',
  'Duerme tranquilo... mamá está aquí.',
  '¿Por qué sigues despierto?',
  'No es lugar para jugar...',
  'Sal del sueño antes de que te encuentre.',
];

export class GameEngine {
  private container: HTMLElement;
  private cb: EngineCallbacks;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private player: PlayerController;
  private world: WorldRefs;
  private monsters!: ForestMonster[];
  private cazador!: CazadorMonster;
  private closet!: ClosetMonster;

  // equipo
  private flashlight!: THREE.SpotLight;
  private flashTarget = new THREE.Object3D();
  private handGroup = new THREE.Group();
  private flashMesh!: THREE.Group;
  private camMesh!: THREE.Group;
  private recLed!: THREE.Mesh;

  // estado
  public phase: 'idle' | 'playing' | 'paused' | 'ending' = 'idle';
  private flashlightOn = false;
  private camOn = false;
  private battery = 100;
  private flashlightBattery = 100;
  private fatigueTimer = 0;
  private lastRadioCount = 0;
  private tvActiveFor = -1;
  private camOffTimer = 0;
  private radios: [boolean, boolean, boolean, boolean, boolean, boolean] = [false, false, false, false, false, false];
  private casaReached = false;
  private score = 0;
  private elapsed = 0;
  private zonesHit = new Set<string>();
  private settings: Settings;
  private activePrompt: string | null = null;
  private activeInteractId: string | null = null;
  private subtitle = '';
  private subtitleTimer = 0;
  private flashTimer = 0;
  private msgTimer = 0;
  private msg = '';
  private interference = 0;
  private cinematic: { mode: 'good' | 'bad' | 'caught'; t: number } | null = null;
  private timeouts: ReturnType<typeof setTimeout>[] = [];
  private heartbeatOn = false;
  private creakedOnce = false;
  private endingFired = false;
  private modelMixers: THREE.AnimationMixer[] = [];
  private sirenHolder: THREE.Group | null = null;

  private raf = 0;
  private last = 0;
  private hudAcc = 0;
  private tvAcc = 0;
  private disposed = false;

  constructor(container: HTMLElement, settings: Settings, cb: EngineCallbacks) {
    this.container = container;
    this.cb = cb;
    this.settings = settings;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(72, 1, 0.08, 260);
    this.world = buildWorld(this.scene, settings.quality);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.applyQuality();
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    container.appendChild(this.renderer.domElement);

    // jugador
    const indoorFn = (p: THREE.Vector3): boolean =>
      Math.abs(p.x - 0) < 5.9 && p.z > -71.6 && p.z < -61.5;
    this.player = new PlayerController(this.camera, this.world.circleCols, this.world.boxCols, indoorFn);
    this.player.setSensitivity(settings.sensitivity);
    this.player.onStep = (run, indoor) => vhsAudio.footstep(run, indoor);
    this.scene.add(this.camera);

    this.buildEquipment();
    this.buildMonsters();
    void this.loadProvidedModels();

    window.addEventListener('resize', this.onResize);
    this.onResize();

    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  // ------------------- EQUIPO -------------------
  private buildEquipment(): void {
    // linterna realista
    this.flashlight = new THREE.SpotLight(0xfff3d6, 0, 48, Math.PI / 5.2, 0.38, 1.15);
    this.flashlight.castShadow = this.settings.quality === 'high';
    this.flashlight.shadow.mapSize.set(512, 512);
    this.scene.add(this.flashlight);
    this.scene.add(this.flashTarget);
    this.flashlight.target = this.flashTarget;

    // manos / equipo en primera persona
    this.flashMesh = new THREE.Group();
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.085, 0.085, 0.3), new THREE.MeshStandardMaterial({ color: 0x1a1f26, roughness: 0.9 }));
    sleeve.position.set(0.02, -0.02, 0.16);
    const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, 0.22, 10), new THREE.MeshStandardMaterial({ color: 0x33363c, metalness: 0.5, roughness: 0.4 }));
    tube.rotation.x = Math.PI / 2;
    tube.position.set(-0.02, 0.01, -0.02);
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.038, 12), new THREE.MeshBasicMaterial({ color: 0xfff3c2 }));
    lens.position.set(-0.02, 0.01, -0.13);
    lens.rotation.y = Math.PI;
    this.flashMesh.add(sleeve, tube, lens);
    this.flashMesh.position.set(0.34, -0.34, -0.6);
    this.flashMesh.rotation.set(-0.1, 0.1, 0);
    this.handGroup.add(this.flashMesh);

    // videocámara antigua
    this.camMesh = new THREE.Group();
    const camBody = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.16, 0.36), new THREE.MeshStandardMaterial({ color: 0x15181d, roughness: 0.5 }));
    const camLens = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.075, 0.14, 12), new THREE.MeshStandardMaterial({ color: 0x05070a, roughness: 0.3 }));
    camLens.rotation.x = Math.PI / 2;
    camLens.position.set(0, 0.02, -0.24);
    this.recLed = new THREE.Mesh(new THREE.SphereGeometry(0.014, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff2020 }));
    this.recLed.position.set(0.1, 0.09, -0.1);
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.14, 0.2), new THREE.MeshStandardMaterial({ color: 0x0c0e12 }));
    handle.position.set(0.13, 0.0, 0.02);
    this.camMesh.add(camBody, camLens, this.recLed, handle);
    this.camMesh.position.set(0.12, -0.06, -0.5);
    this.camMesh.visible = false;
    this.handGroup.add(this.camMesh);

    this.camera.add(this.handGroup);
  }

  // ------------------- MONSTRUOS -------------------
  private buildMonsters(): void {
    const sp = this.world.monsterSpawns;
    this.monsters = [
      new ForestMonster('alto', sp.alto),
      new ForestMonster('rastrero', sp.rastrero),
      new ForestMonster('deforme', sp.deforme),
    ];
    this.monsters.forEach((m) => this.scene.add(m.group));
    this.cazador = new CazadorMonster((p) => Math.abs(p.x) < 5.9 && p.z > -71.6 && p.z < -61.6);
    this.scene.add(this.cazador.group);
    this.closet = new ClosetMonster();
    this.scene.add(this.closet.group);
    this.closet.place(new THREE.Vector3(3.15, 0, -71.55), Math.PI); // dentro del armario, mirando al sur
  }

  private async loadProvidedModels(): Promise<void> {
    const mixer1 = await loadVisualModel('/assets/monstruo_nocturno.glb', this.monsters[1].group, 2.2, 0);
    const mixer2 = await loadVisualModel('/assets/gigant_zombie.glb', this.monsters[0].group, 4.8, 0);
    const mother = await loadVisualModel('/assets/mother..glb', this.closet.group, 1.8, 0);
    if (mixer1) this.modelMixers.push(mixer1);
    if (mixer2) this.modelMixers.push(mixer2);
    if (mother) this.modelMixers.push(mother);
    const sirenHolder = new THREE.Group();
    sirenHolder.visible = false;
    this.scene.add(sirenHolder);
    const siren = await loadVisualModel('/assets/siren_head.glb', sirenHolder, 9.5, 0);
    if (siren) this.modelMixers.push(siren);
    this.sirenHolder = sirenHolder;
  }

  private makeCtx(): Parameters<ForestMonster['update']>[2] {
    return {
      playerPos: this.player.pos,
      playerRunning: this.player.running && this.player.speed > 4,
      flashlightOn: this.flashlightOn,
      camOn: this.camOn,
      camForward: this.player.forward(),
      los: (ax, az, bx, bz) => hasLos(ax, az, bx, bz, this.world.circleCols, this.world.boxCols),
      resolveMove: (from, desired) =>
        collideMove(from, desired, 0.55, this.world.circleCols, this.world.boxCols),
      alert: (kind, pos) => this.handleAlert(kind, pos),
      onCaught: () => this.handleCaught(),
      onStep: (dist) => {
        const g = THREE.MathUtils.clamp(0.5 - dist * 0.02, 0.02, 0.5);
        vhsAudio.monsterStep(g);
      },
      onSurvive: () => {
        this.addScore(200, 'EL CAZADOR PERDIÓ TU RASTRO');
      },
    };
  }

  // ------------------- ALERTA / RISAS -------------------
  private handleAlert(kind: string, pos: THREE.Vector3): void {
    // El Cazador investiga un punto cercano con ruido gaussiano
    const jitter = new THREE.Vector3(
      pos.x + (Math.random() - 0.5) * 8, 0,
      pos.z + (Math.random() - 0.5) * 8
    );
    // a veces solo "escucha" aproximado al jugador
    const delay = kind === 'deforme' ? 700 + Math.random() * 900 : 1400 + Math.random() * 2600;
    const to = setTimeout(() => {
      if (this.disposed || this.phase !== 'playing') return;
      this.cazador.alert(jitter, this.player.pos);
    }, delay);
    this.timeouts.push(to);
    // risa lejana que parece responder desde otra dirección
    if (Math.random() < 0.45) {
      const echoTo = setTimeout(() => {
        if (this.disposed || this.phase !== 'playing') return;
        vhsAudio.laugh(kind as 'alto', 0.35);
      }, 2500 + Math.random() * 3500);
      this.timeouts.push(echoTo);
    }
    this.flashTimer = Math.max(this.flashTimer, 0.5);
  }

  // ------------------- API PÚBLICA -------------------
  startRun(freshRadios?: [boolean, boolean, boolean, boolean, boolean, boolean], freshScore = 0): void {
    this.clearTimeouts();
    this.phase = 'playing';
    this.cinematic = null;
    this.endingFired = false;
    this.creakedOnce = false;
    this.radios = freshRadios ? [...freshRadios] as typeof this.radios : [false, false, false, false, false, false];
    this.casaReached = false;
    this.score = freshScore;
    this.elapsed = 0;
    this.battery = 100;
    this.flashlightBattery = 100;
    this.fatigueTimer = 0;
    this.lastRadioCount = 0;
    this.camOn = false;
    this.flashlightOn = true;
    this.zonesHit = new Set();
    this.subtitle = '';
    this.msg = '';
    this.player.reset(0, freshRadios && freshRadios.some((r) => r) ? -56 : 46, Math.PI);
    if (freshRadios && freshRadios.some((r) => r)) {
      this.player.reset(0, -56, Math.PI);
    }
    this.monsters.forEach((m) => m.reset());
    this.cazador.reset();
    this.closet.reset();
    this.closet.place(new THREE.Vector3(3.15, 0, -71.55), Math.PI);
    this.world.closetDoor.rotation.y = 0;
    this.world.houseLight.intensity = 1.2;
    for (const k of ['radio1','radio2','radio3','radio4','radio5','radio6'] as const) {
      const lit = this.world.radioLights[k];
      const collected = this.radios[Number(k.slice(-1)) - 1];
      lit.intensity = collected ? 0.12 : 0.6;
    }
    vhsAudio.startAmbient();
    vhsAudio.flashlightClick(true);
    this.emitHud(true);
  }

  pause(): void {
    if (this.phase !== 'playing') return;
    this.phase = 'paused';
    vhsAudio.stopHeartbeat();
    ctxPause(this.heartbeatOn, () => (this.heartbeatOn = false));
    document.exitPointerLock?.();
  }

  resume(): void {
    if (this.phase !== 'paused') return;
    this.phase = 'playing';
    vhsAudio.startAmbient();
  }

  stopAll(): void {
    this.phase = 'idle';
    vhsAudio.stopAmbient();
    vhsAudio.stopHeartbeat();
    this.clearTimeouts();
  }

  toggleFlashlight(): void {
    if (this.phase !== 'playing') return;
    if (!this.flashlightOn && this.flashlightBattery <= 0) return;
    this.flashlightOn = !this.flashlightOn;
    vhsAudio.flashlightClick(this.flashlightOn);
  }

  toggleCam(): void {
    if (this.phase !== 'playing') return;
    if (this.camOn) {
      this.camOn = false;
      vhsAudio.camToggle(false);
    } else if (this.battery > 4) {
      this.camOn = true;
      vhsAudio.camToggle(true);
    }
  }

  requestPointerLock(): void {
    this.renderer.domElement.requestPointerLock?.();
  }

  interact(): void {
    if (this.phase !== 'playing' || !this.activeInteractId) return;
    const id = this.activeInteractId;
    if (id.startsWith('radio')) {
      const idx = Number(id.slice(-1)) - 1;
      if (this.radios[idx]) return;
      this.radios[idx] = true;
      const rl = this.world.radioLights[id];
      rl.intensity = 0.12;
      this.showSubtitle(`«${RADIO_TEXTS[idx]}»`, 3.6);
      vhsAudio.pickup();
      const tone = idx === 2 ? { pitch: 0.7, rate: 0.62 } : { pitch: 0.85, rate: 0.7 };
      vhsAudio.speak(RADIO_TEXTS[idx], tone);
      this.addScore(500, `GRABACIÓN ${idx + 1} ESCUCHADA`);
      // Sin checkpoints: las grabaciones no guardan el progreso.
      this.triggerRandomTv(idx);
      // el sonido de la grabadora puede atraer al Cazador
      if (Math.random() < 0.35) {
        this.handleAlert('deforme', this.player.pos.clone());
      }
    } else if (id === 'cama') {
      const all = this.radios.every(Boolean);
      if (all) this.startGoodEnding();
      else this.startBadEnding();
    }
  }

  private triggerRandomTv(idx: number): void {
    this.tvActiveFor = Math.floor(Math.random() * 6);
    this.interference = Math.max(this.interference, 0.72);
    this.showSubtitle(this.tvActiveFor % 3 === 0 ? '«Vete a dormir rápido...»' : this.tvActiveFor % 3 === 1 ? '«No es lugar para jugar...»' : '«¿Por qué sigues despierto?»', 4.2);
    vhsAudio.glitchBurst(0.22);
  }

  giveMobileMove(x: number, y: number): void {
    this.player.setTouchMove(x, y);
  }
  giveMobileRun(v: boolean): void { this.player.setTouchRun(v); }
  giveMobileCrouch(v: boolean): void { this.player.setTouchCrouch(v); }
  giveLook(dx: number, dy: number): void {
    if (this.phase === 'playing') this.player.addLook(dx, dy);
  }

  applySettings(s: Settings): void {
    this.settings = s;
    this.player.setSensitivity(s.sensitivity);
    vhsAudio.setVolume(s.volume);
    this.applyQuality();
  }

  private applyQuality(): void {
    const q = this.settings.quality;
    const pr = q === 'high' ? Math.min(devicePixelRatio || 1, 2) : q === 'medium' ? Math.min(devicePixelRatio || 1, 1.5) : 1;
    this.renderer.setPixelRatio(pr);
    this.renderer.shadowMap.enabled = q !== 'low';
    if (this.scene.fog) (this.scene.fog as THREE.FogExp2).density = q === 'high' ? 0.014 : q === 'medium' ? 0.018 : 0.024;
  }

  // ------------------- FINALES -------------------
  private startGoodEnding(): void {
    if (this.cinematic) return;
    this.cinematic = { mode: 'good', t: 0 };
    this.player.locked = true;
    this.subtitle = '«Duerme tranquilo... mamá está aquí.»';
    this.subtitleTimer = 8;
    vhsAudio.speak('Duerme tranquilo... mamá está aquí.', { pitch: 0.7, rate: 0.66 });
    this.addScore(1000, 'FINAL: ESCAPASTE DEL SUEÑO');
  }

  private startBadEnding(): void {
    if (this.cinematic) return;
    this.cinematic = { mode: 'bad', t: 0 };
    this.player.locked = true;
    this.world.houseLight.intensity = 0.05;
    this.flashlightOn = false;
    vhsAudio.glitchBurst(0.25);
    this.showSubtitle('El aliento del bosque se detiene...', 2.4);
  }

  private handleCaught(): void {
    if (this.cinematic || this.phase !== 'playing') return;
    this.cinematic = { mode: 'caught', t: 0 };
    this.player.locked = true;
    vhsAudio.catchScream();
    vhsAudio.glitchBurst(0.5);
    this.flashTimer = 1.2;
    // el cazador salta a la cara
    const f = this.player.forward();
    this.cazador.group.position.set(this.player.pos.x + f.x * 1.0, 0, this.player.pos.z + f.z * 1.0);
    this.cazador.group.lookAt(this.player.pos.x, 1.4, this.player.pos.z);
    this.cazador.group.visible = true;
    if (this.sirenHolder) {
      const f2 = this.player.forward();
      this.sirenHolder.position.set(this.player.pos.x - f2.x * 0.8, 0, this.player.pos.z - f2.z * 0.8);
      this.sirenHolder.visible = true;
      this.sirenHolder.lookAt(this.player.pos.x, 1.4, this.player.pos.z);
    }
  }

  private finishEnding(): void {
    if (!this.cinematic || this.endingFired) return;
    this.endingFired = true;
    const mode = this.cinematic.mode;
    this.phase = 'ending';
    this.stopHeartbeatNow();
    document.exitPointerLock?.();
    const sum: EndingSummary = {
      mode,
      score: Math.floor(this.score),
      timeSec: Math.floor(this.elapsed),
      radios: this.radios.filter(Boolean).length,
    };
    this.clearTimeouts();
    this.cb.onEnding(sum);
  }

  private stopHeartbeatNow(): void {
    if (this.heartbeatOn) {
      vhsAudio.stopHeartbeat();
      this.heartbeatOn = false;
    }
  }

  // ------------------- UTILIDADES -------------------
  private addScore(pts: number, reason: string): void {
    this.score += pts;
    this.msg = `+${pts} · ${reason}`;
    this.msgTimer = 3;
    this.cb.onMessage(this.msg);
  }

  private showSubtitle(text: string, dur: number): void {
    this.subtitle = text;
    this.subtitleTimer = dur;
  }

  private clearTimeouts(): void {
    this.timeouts.forEach((t) => clearTimeout(t));
    this.timeouts = [];
  }

  private onResize = (): void => {
    if (this.disposed) return;
    const w = this.container.clientWidth || innerWidth;
    const h = this.container.clientHeight || innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  // ------------------- BUCLE PRINCIPAL -------------------
  private loop = (now: number): void => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, (now - this.last) / 1000);
    const t = now * 0.001;

    if (this.phase === 'playing' || this.phase === 'ending') {
      this.elapsed += this.phase === 'playing' ? dt : 0;
      if (!this.endingFired) {
        this.player.update(dt);
        this.updateEquipment(dt, t);
        const ctx = this.makeCtx();
        for (const m of this.monsters) m.update(dt, t, ctx);
        this.cazador.update(dt, t, ctx);
        this.closet.update(dt, t);
        for (const mixer of this.modelMixers) mixer.update(dt);
        if (this.phase === 'playing') {
          this.updateInteractions();
          this.updateZones();
          this.updateBattery(dt);
          this.updateChaseAudio();
          this.updateCinematic(dt);
          this.updateRevealAndInterference(dt);
        } else if (this.cinematic) {
          this.updateCinematic(dt);
        }
      }
      this.updateRadioLights(t);
      this.updateTvStatic(dt, t);
    } else if (this.phase === 'paused') {
      // congelado
    } else {
      // menú: cámara orbital lenta sobre el bosque
      const r = 30;
      this.camera.position.set(Math.cos(t * 0.05) * r, 6 + Math.sin(t * 0.1) * 1.5, 20 + Math.sin(t * 0.05) * 18);
      this.camera.lookAt(0, 1.5, -30);
      this.updateRadioLights(t);
    }

    if (this.subtitleTimer > 0) {
      this.subtitleTimer -= dt;
      if (this.subtitleTimer <= 0) this.subtitle = '';
    }
    if (this.msgTimer > 0) {
      this.msgTimer -= dt;
      if (this.msgTimer <= 0) this.msg = '';
    }
    if (this.flashTimer > 0) this.flashTimer -= dt;
    this.handGroup.visible = (this.phase === 'playing' || this.phase === 'ending') && !this.endingFired;

    this.hudAcc += dt;
    if (this.hudAcc > 0.08) {
      this.hudAcc = 0;
      if (this.phase === 'playing' || this.phase === 'ending') this.emitHud();
    }

    this.renderer.render(this.scene, this.camera);
    this.last = now;
  };

  private updateEquipment(dt: number, t: number): void {
    // linterna sigue la vista
    const f = this.player.forward();
    this.flashlight.visible = this.flashlightOn && this.phase !== 'idle';
    if (this.flashlight.visible) {
      this.flashlight.position.copy(this.camera.position).add(new THREE.Vector3(f.x * 0.15, -0.12, f.z * 0.15));
      this.flashTarget.position.copy(this.camera.position).add(f.clone().multiplyScalar(10));
      const low = THREE.MathUtils.clamp(this.flashlightBattery / 25, 0.22, 1);
      const intensity = 8.5 * low;
      this.flashlight.distance = 48 * (0.55 + 0.45 * low);
      this.flashlight.intensity = THREE.MathUtils.lerp(this.flashlight.intensity, intensity, dt * 10);
    } else {
      this.flashlight.intensity = 0;
    }
    // manos: bob lento
    const bob = Math.sin(this.player.bobPhase * 2) * 0.018;
    this.flashMesh.position.y = -0.34 + bob;
    this.flashMesh.visible = !this.camOn;
    this.camMesh.visible = this.camOn;
    this.camMesh.position.y = -0.06 + bob * 1.4;
    this.camMesh.position.x = 0.12 + Math.sin(t * 1.2) * 0.006;
    // luz REC parpadea
    if (this.camOn) this.recLed.material = (t * 1.6) % 1 < 0.5 ? new THREE.MeshBasicMaterial({ color: 0xff2020 }) : new THREE.MeshBasicMaterial({ color: 0x500808 });
  }

  private updateBattery(dt: number): void {
    if (this.camOn) {
      this.battery = Math.max(0, this.battery - dt * 3.0);
      if (this.battery === 0) {
        this.camOn = false;
        vhsAudio.camToggle(false);
        this.startBatteryDeath();
      }
    } else {
      this.camOffTimer += dt;
    }
    if (this.flashlightOn) {
      this.flashlightBattery = Math.max(0, this.flashlightBattery - dt * 0.12);
      if (this.flashlightBattery === 0) { this.flashlightOn = false; vhsAudio.flashlightClick(false); }
    }
    const count = this.radios.filter(Boolean).length;
    if (count > this.lastRadioCount) {
      this.lastRadioCount = count;
      this.fatigueTimer = count >= 3 ? 6 : 0;
      this.player.setTired(count >= 4);
      if (count >= 4) this.showSubtitle('«Me siento... cansado...»', 3.2);
    }
  }

  private startBatteryDeath(): void {
    if (this.cinematic || this.phase !== 'playing') return;
    this.cinematic = { mode: 'bad', t: 0 };
    this.player.locked = true;
    this.flashlightOn = false;
    this.showSubtitle('«No me siento... no me siento...»', 4);
    vhsAudio.glitchBurst(0.45);
  }

  private updateRevealAndInterference(dt: number): void {
    let nearest = 999;
    const f = this.player.forward();
    const apply = (m: { group: THREE.Object3D; setRevealed: (b: boolean) => void; revealed: boolean }): void => {
      const g = m.group.position;
      if (!m.group.visible) {
        if (m.revealed) m.setRevealed(false);
        return;
      }
      const dx = g.x - this.player.pos.x;
      const dz = g.z - this.player.pos.z;
      const d = Math.hypot(dx, dz);
      nearest = Math.min(nearest, d);
      if (this.camOn && d < 46) {
        const safeD = Math.max(0.001, d);
        const dot = (dx / safeD) * f.x + (dz / safeD) * f.z;
        if (dot > 0.86) {
          m.setRevealed(true);
          return;
        }
      }
      if (m.revealed) m.setRevealed(false);
    };
    for (const mo of this.monsters) apply(mo);
    apply(this.cazador);

    const targetI = this.camOn && nearest < 30 ? 0.42 + (30 - nearest) * 0.012 : this.cazador.isHunting() ? 0.3 : 0.1;
    this.interference = THREE.MathUtils.lerp(this.interference, targetI, dt * 3);
  }

  private updateInteractions(): void {
    this.activeInteractId = null;
    this.activePrompt = null;
    let best = 99;
    for (const it of this.world.interactables) {
      const d = Math.hypot(it.x - this.player.pos.x, it.z - this.player.pos.z);
      if (d < it.radius && d < best) {
        // si ya se escuchó la grabación, no mostrar
        if (it.id.startsWith('radio') && this.radios[Number(it.id.slice(-1)) - 1]) continue;
        best = d;
        this.activeInteractId = it.id;
        this.activePrompt = `[E] ${it.label}`;
      }
    }
  }

  private updateZones(): void {
    for (const z of this.world.zones) {
      if (this.zonesHit.has(z.id)) continue;
      const d = Math.hypot(z.x - this.player.pos.x, z.z - this.player.pos.z);
      if (d < z.r) {
        this.zonesHit.add(z.id);
        this.addScore(z.pts, `LUGAR: ${z.name}`);
        if (z.id === 'dormitorio') {
          this.casaReached = true;
          // checkpoint desactivado intencionalmente
        }
      }
    }
  }

  private updateChaseAudio(): void {
    const hunting = this.cazador.isHunting();
    if (hunting && !this.heartbeatOn) {
      vhsAudio.startHeartbeat();
      this.heartbeatOn = true;
    } else if (!hunting && this.heartbeatOn) {
      vhsAudio.stopHeartbeat();
      this.heartbeatOn = false;
    }
  }

  private updateRadioLights(t: number): void {
    (['radio1','radio2','radio3','radio4','radio5','radio6'] as const).forEach((k, i) => {
      if (this.radios[i]) return;
      this.world.radioLights[k].intensity = 0.45 + Math.sin(t * 2.1 + i * 1.4) * 0.28;
    });
  }

  private updateTvStatic(dt: number, t: number): void {
    this.tvAcc += dt;
    if (this.tvAcc < 0.08) return;
    this.tvAcc = 0;
    const ctx = this.world.tvCtx;
    const w = 128, h = 96;
    const img = ctx.createImageData(w, h);
    const d = img.data;
    for (let i = 0; i < d.length; i += 4) {
      const v = (Math.random() * 105) | 0;
      d[i] = v; d[i + 1] = v; d[i + 2] = v; d[i + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    ctx.fillStyle = 'rgba(180,190,200,0.7)';
    ctx.font = '10px monospace';
    ctx.fillText(`CH-9 ${((t * 4) % 99).toFixed(0).padStart(2, '0')}`, 6, 14);
    if (this.tvActiveFor >= 0) {
      const lines = ['VETE A DORMIR','NO ES LUGAR PARA JUGAR','¿POR QUÉ SIGUES DESPIERTO?','DUERME...','SAL DEL SUEÑO','NO TE ESCONDAS'];
      ctx.fillStyle = 'rgba(235,235,235,0.95)';
      ctx.font = '8px monospace';
      ctx.fillText(lines[this.tvActiveFor], 8, 48);
      ctx.fillStyle = 'rgba(220,220,220,0.65)';
      ctx.fillText('...MOTHER...', 38, 63);
    }
    this.world.tvCanvasTexture.needsUpdate = true;
  }

  // ------------------- CINEMÁTICAS -------------------
  private updateCinematic(dt: number): void {
    if (!this.cinematic) return;
    this.cinematic.t += dt;
    const c = this.cinematic;

    if (c.mode === 'caught') {
      // sacudida y salto contracara
      this.camera.position.y = this.player.pos.y + Math.sin(c.t * 40) * 0.06 * Math.max(0, 1.2 - c.t);
      this.flashTimer = 0.4;
      if (this.sirenHolder && c.t < 1.3) { this.sirenHolder.scale.setScalar(1 + Math.max(0, c.t - 0.7) * 0.8); }
      if (c.t > 1.6) this.finishEnding();
      return;
    }

    if (c.mode === 'good') {
      // acostarse: cámara desciende suave, pitch hacia el techo
      this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, 1.0, dt * 0.6);
      this.player.pitch = THREE.MathUtils.lerp(this.player.pitch, 0.9, dt * 0.5);
      this.interference = Math.max(this.interference, Math.min(0.4, c.t * 0.12));
      if (c.t > 7.5) this.finishEnding();
      return;
    }

    // FINAL MALO / MUERTE POR BATERÍA
    if (this.cinematic.mode === 'bad' && this.flashlightBattery <= 0 && c.t < 5.5) {
      this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, 0.65, dt * 0.7);
      this.player.pitch = THREE.MathUtils.lerp(this.player.pitch, -0.55, dt * 0.6);
      this.interference = Math.min(1, 0.35 + c.t * 0.14);
      if (c.t > 5.0) this.finishEnding();
      return;
    }
    // FINAL MALO
    const closetDoor = this.world.closetDoor;
    if (c.t > 0.6 && !this.creakedOnce) {
      this.creakedOnce = true;
      vhsAudio.creak();
      this.showSubtitle('El armario cruje...', 2.2);
    }
    if (c.t > 0.8 && c.t < 4.6) {
      const s = (c.t - 0.8) / 3.8;
      closetDoor.rotation.y = -1.85 * s;
    }
    if (c.t > 3.2 && !this.closet.emerged) {
      this.closet.emerge(this.world.bedPos.clone().setY(0).add(new THREE.Vector3(-1.4, 0, 1.0)), () => {
        vhsAudio.glitchBurst(0.35);
        this.showSubtitle('«Hey... mamá ya no está.»', 4);
        vhsAudio.speak('Hey. Mamá ya no está.', { pitch: 0.22, rate: 0.55 });
      });
    }
    if (this.closet.emerged) {
      // mirar hacia la criatura
      const mp = this.closet.group.position;
      const dx = mp.x - this.player.pos.x;
      const dz = mp.z - this.player.pos.z;
      this.player.yaw = Math.atan2(-dx, -dz);
      this.player.pitch = THREE.MathUtils.lerp(this.player.pitch, -0.15, dt * 2);
      this.camera.position.y = 1.62 + Math.sin(c.t * 6) * 0.02;
      this.interference = Math.min(1, 0.5 + c.t * 0.06);
    }
    if (c.t > 13.5) this.finishEnding();
  }

  // ------------------- HUD -------------------
  private emitHud(force = false): void {
    void force;
    const mm = Math.floor((this.elapsed / 60) % 60).toString().padStart(2, '0');
    const ss = Math.floor(this.elapsed % 60).toString().padStart(2, '0');
    this.cb.onHud({
      timestamp: `OCT. 31 1993   00:${mm}:${ss}`,
      battery: Math.round(this.battery),
      flashlightBattery: Math.round(this.flashlightBattery),
      flashlightOn: this.flashlightOn,
      camOn: this.camOn,
      chaseActive: this.cazador.isHunting(),
      score: Math.floor(this.score),
      prompt: this.activePrompt,
      subtitle: this.subtitle || null,
      radios: [...this.radios],
      casaReached: this.casaReached,
      dangerFlash: this.flashTimer > 0,
      interference: this.interference,
      message: this.msg || null,
    });
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.clearTimeouts();
    vhsAudio.stopAmbient();
    vhsAudio.stopHeartbeat();
    this.player.dispose();
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}

function ctxPause(_flag: boolean, setter: () => void): void {
  void _flag;
  setter();
  vhsAudio.stopHeartbeat();
}
