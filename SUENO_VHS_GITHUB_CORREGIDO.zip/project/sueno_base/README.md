# SUEÑO VHS — NO DESPIERTES

Base del proyecto preservada: React + Vite + Three.js.

## Cambios de esta revisión

- Corregidos los ejes del movimiento del jugador para que avanzar/retroceder coincidan con la dirección real de la cámara.
- Reinicio del estado de carrera táctil al iniciar una partida.
- Reforzada la captura y liberación de puntero en joystick y zona de cámara táctil.
- Ampliado el terreno jugable y el límite del bosque; aumentada la población instanciada de árboles, rocas y arbustos según calidad.
- Aumentada la distancia de cámara y suavizada la niebla para recuperar visibilidad en el bosque extendido.
- Mejorado el alcance y la potencia de la linterna.
- El Cazador despierta desde una posición fija y se desplaza hacia el ruido: ya no aparece teletransportado junto al jugador.
- Los tres monstruos del bosque pueden alertar al Cazador y sus desplazamientos respetan las colisiones del escenario.
- Añadidos dedos largos al Alto, garras al Rastrero y zarpas al Cazador; ensanchada la silueta de la cabeza del Alto.
- Sustituidos los modelos visuales de radio por grabadoras portátiles de casete con ventana, carretes, rejilla y botones.
- Cambiado el lenguaje visible de objetivos y finales a grabaciones/casetes; REC permanece visible durante la partida.
- Sustituido el tinte verde de cámara por un tratamiento frío y desaturado.

## Ejecución

Requiere Node.js. Instalar dependencias con `npm install` y ejecutar `npm run dev`.

Nota: en este entorno no fue posible completar la instalación de dependencias desde npm, por lo que se verificó la sintaxis TypeScript/TSX y comprobaciones estáticas, pero no se pudo ejecutar un build Vite ni probar el juego en un dispositivo Android real.

## Correcciones de esta revisión

- Las seis grabaciones se reubicaron en sectores separados del mapa; se retiraron dos ubicaciones interiores cercanas entre sí.
- Se sustituyó el monstruo procedural genérico del armario por la entidad `MotherEntity`, que utiliza el modelo `mother..glb` ya incluido.
- Se añadieron hojas de puerta con marco, paneles y pomos para la entrada y el dormitorio; ambas se abren suavemente al acercarse el jugador.
- El grano VHS ahora solo se muestra al activar la cámara, con intensidad reducida. La cámara aplica desaturación y contraste moderado al render, sin reducir resolución.
- La linterna comienza con 50 % de batería.
- La orientación de aparición de Siren Head se calcula en el plano horizontal para evitar inclinarlo al mirar al jugador.
- Se conserva Node 22 en GitHub Actions para Capacitor 8.

## Estado de verificación

Se realizó una comprobación sintáctica de los 12 archivos TypeScript/TSX (sin diagnósticos). No se pudo completar `npm install` en el entorno de preparación, por lo que esta revisión todavía requiere ejecutar `npm install` y `npm run build` en GitHub Actions y probar el APK en Android. Las puertas se abren por proximidad; no son una interacción manual independiente.
