import * as THREE from 'three';
import { Quality } from '../types/game';

// ---------- Tipos de colisión ----------
export interface CircleCol { x: number; z: number; r: number; blocksLos: boolean }
export interface BoxCol { minX: number; maxX: number; minZ: number; maxZ: number; blocksLos: boolean }

export interface Interactable {
  id: 'radio1' | 'radio2' | 'radio3' | 'radio4' | 'radio5' | 'radio6' | 'cama';
  label: string;
  x: number; y: number; z: number;
  radius: number;
}

export interface ZoneDef { id: string; name: string; x: number; z: number; r: number; pts: number }

export interface WorldRefs {
  electricFence: { posts: THREE.Group; wires: THREE.Mesh[]; lights: THREE.PointLight[]; flicker: number };
  scene: THREE.Scene;
  circleCols: CircleCol[];
  boxCols: BoxCol[];
  interactables: Interactable[];
  zones: ZoneDef[];
  radioMeshes: Record<'radio1'|'radio2'|'radio3'|'radio4'|'radio5'|'radio6', THREE.Group>;
  radioLights: Record<'radio1'|'radio2'|'radio3'|'radio4'|'radio5'|'radio6', THREE.PointLight>;
  closetGroup: THREE.Group;
  closetDoor: THREE.Group;
  bedPos: THREE.Vector3;
  bedroomPos: THREE.Vector3;
  houseDoorPos: THREE.Vector3;
  houseDoor: THREE.Group;
  bedroomDoor: THREE.Group;
  monsterSpawns: Record<'alto' | 'rastrero' | 'deforme', THREE.Vector3[]>;
  tvCanvasTexture: THREE.CanvasTexture;
  tvCtx: CanvasRenderingContext2D;
  houseLight: THREE.PointLight;
}

// RNG determinista para recrear el mismo bosque en cada partida
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- Resolución de colisión jugador --------
export function collideMove(
  cur: THREE.Vector3,
  desired: THREE.Vector3,
  radius: number,
  circles: CircleCol[],
  boxes: BoxCol[]
): THREE.Vector3 {
  const p = desired.clone();
  p.y = cur.y;
  for (let iter = 0; iter < 2; iter++) {
    for (const c of circles) {
      const dx = p.x - c.x;
      const dz = p.z - c.z;
      const d = Math.hypot(dx, dz);
      const minD = c.r + radius;
      if (d < minD && d > 0.0001) {
        const push = (minD - d) / d;
        p.x += dx * push;
        p.z += dz * push;
      }
    }
    for (const b of boxes) {
      const nx = Math.max(b.minX, Math.min(p.x, b.maxX));
      const nz = Math.max(b.minZ, Math.min(p.z, b.maxZ));
      const dx = p.x - nx;
      const dz = p.z - nz;
      const d = Math.hypot(dx, dz);
      if (d < radius) {
        if (d > 0.0001) {
          p.x = nx + (dx / d) * radius;
          p.z = nz + (dz / d) * radius;
        } else {
          // dentro del volumen: empuja por el eje más cercano
          const dl = p.x - b.minX, dr = b.maxX - p.x, db = p.z - b.minZ, df = b.maxZ - p.z;
          const m = Math.min(dl, dr, db, df);
          if (m === dl) p.x = b.minX - radius; else if (m === dr) p.x = b.maxX + radius;
          else if (m === db) p.z = b.minZ - radius; else p.z = b.maxZ + radius;
        }
      }
    }
  }
  // límite del bosque
  const distC = Math.hypot(p.x, p.z + 12);
  if (distC > 190) {
    const s = 190 / distC;
    p.x *= s;
    p.z = (p.z + 12) * s - 12;
  }
  return p;
}

// Línea de visión 2D contra colisiones de círculos y cajas
export function hasLos(
  ax: number, az: number, bx: number, bz: number,
  circles: CircleCol[], boxes: BoxCol[]
): boolean {
  const dx = bx - ax, dz = bz - az;
  const len = Math.hypot(dx, dz);
  if (len < 0.001) return true;
  const dirX = dx / len, dirZ = dz / len;

  for (const c of circles) {
    if (!c.blocksLos) continue;
    // proyección centro sobre rayo
    const cx = c.x - ax, cz = c.z - az;
    const t = cx * dirX + cz * dirZ;
    if (t < 0.5 || t > len - 0.5) continue;
    const px = ax + dirX * t, pz = az + dirZ * t;
    const hd = Math.hypot(c.x - px, c.z - pz);
    if (hd < c.r) return false;
  }
  for (const b of boxes) {
    if (!b.blocksLos) continue;
    // método slab
    let tmin = 0, tmax = len;
    if (Math.abs(dirX) < 1e-6) {
      if (ax < b.minX || ax > b.maxX) continue;
    } else {
      let t1 = (b.minX - ax) / dirX, t2 = (b.maxX - ax) / dirX;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
    }
    if (Math.abs(dirZ) < 1e-6) {
      if (az < b.minZ || az > b.maxZ) continue;
    } else {
      let t1 = (b.minZ - az) / dirZ, t2 = (b.maxZ - az) / dirZ;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
    }
    if (tmax >= tmin && tmax > 0.5 && tmin < len - 0.5) return false;
  }
  return true;
}

// ---------- Construcción del mundo ----------
const HOUSE = { x: 0, z: -66.5, w: 11.5, d: 9.5, h: 3.0 };
const SHED = { x: 26, z: -16, w: 3.6, d: 3.4, h: 2.4 };

export function buildWorld(scene: THREE.Scene, quality: Quality): WorldRefs {
  const circleCols: CircleCol[] = [];
  const boxCols: BoxCol[] = [];
  const rand = mulberry32(19931031);

  scene.background = new THREE.Color(0x030504);
  scene.fog = new THREE.FogExp2(0x080c12, quality === 'high' ? 0.014 : quality === 'medium' ? 0.018 : 0.024);

  // ---------- Valla eléctrica de pesadilla ----------
  // Modelo 3D ligero: postes, aisladores y varios hilos emisivos.
  // Se mantiene como geometría real para no depender de sprites.
  const fencePosts = new THREE.Group();
  const fenceWires: THREE.Mesh[] = [];
  const fenceLights: THREE.PointLight[] = [];
  const postGeo = new THREE.BoxGeometry(0.16, 2.65, 0.16);
  const postMat = new THREE.MeshStandardMaterial({ color: 0x171b1d, metalness: 0.55, roughness: 0.55 });
  const insGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.18, 8);
  const insMat = new THREE.MeshStandardMaterial({ color: 0x22282b, metalness: 0.35, roughness: 0.45 });
  const wireGeo = new THREE.CylinderGeometry(0.018, 0.018, 1, 6);
  const wireMat = new THREE.MeshStandardMaterial({ color: 0x9fd8ff, emissive: 0x4bb7ff, emissiveIntensity: 1.7, metalness: 0.25, roughness: 0.35 });
  const addFenceSegment = (a: THREE.Vector3, b: THREE.Vector3) => {
    const len = a.distanceTo(b);
    const count = Math.max(2, Math.ceil(len / 2.7));
    const dir = b.clone().sub(a).normalize();
    for (let i = 0; i <= count; i++) {
      const p = a.clone().lerp(b, i / count);
      const post = new THREE.Mesh(postGeo, postMat);
      post.position.copy(p); post.position.y = 1.325; post.castShadow = quality === 'high';
      fencePosts.add(post);
      for (const y of [0.72, 1.34, 1.98, 2.5]) {
        const ins = new THREE.Mesh(insGeo, insMat);
        ins.rotation.z = Math.PI / 2;
        ins.position.set(p.x, y, p.z);
        fencePosts.add(ins);
      }
    }
    for (const y of [0.72, 1.34, 1.98, 2.5]) {
      const mid = a.clone().add(b).multiplyScalar(0.5);
      const wire = new THREE.Mesh(wireGeo, wireMat);
      wire.position.set(mid.x, y, mid.z);
      wire.scale.y = len;
      wire.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), dir);
      fencePosts.add(wire); fenceWires.push(wire);
    }
  };
  // Tres lados alrededor de la casa; el frente conserva una entrada amplia.
  addFenceSegment(new THREE.Vector3(-7.6,0,-75.2), new THREE.Vector3(7.6,0,-75.2));
  addFenceSegment(new THREE.Vector3(-7.6,0,-75.2), new THREE.Vector3(-7.6,0,-57.8));
  addFenceSegment(new THREE.Vector3(7.6,0,-75.2), new THREE.Vector3(7.6,0,-57.8));
  addFenceSegment(new THREE.Vector3(-7.6,0,-57.8), new THREE.Vector3(-3.4,0,-57.8));
  addFenceSegment(new THREE.Vector3(3.4,0,-57.8), new THREE.Vector3(7.6,0,-57.8));
  const fenceGlow = new THREE.PointLight(0x63c8ff, quality === 'high' ? 0.9 : 0.55, 8, 1.7);
  const fencePositions = [new THREE.Vector3(-7.6,1.5,-75.2), new THREE.Vector3(7.6,1.5,-75.2), new THREE.Vector3(-7.6,1.5,-57.8), new THREE.Vector3(7.6,1.5,-57.8)];
  fencePositions.forEach((p) => { const l = fenceGlow.clone(); l.position.copy(p); fencePosts.add(l); fenceLights.push(l); });
  scene.add(fencePosts);
  for (const p of fencePositions) boxCols.push({ minX:p.x-0.13, maxX:p.x+0.13, minZ:p.z-0.13, maxZ:p.z+0.13, blocksLos:true });
  const electricFence = { posts: fencePosts, wires: fenceWires, lights: fenceLights, flicker: 1 };

  // ---------- Iluminación ----------
  const hemi = new THREE.HemisphereLight(0x2a3540, 0x050704, 0.35);
  scene.add(hemi);
  const moon = new THREE.DirectionalLight(0x8fa3b8, 0.32);
  moon.position.set(-30, 40, -20);
  if (quality !== 'low') {
    moon.castShadow = true;
    moon.shadow.mapSize.set(1024, 1024);
    moon.shadow.camera.left = -110; moon.shadow.camera.right = 110;
    moon.shadow.camera.top = 110; moon.shadow.camera.bottom = -110;
    moon.shadow.camera.far = 260;
  }
  scene.add(moon);

  // ---------- Suelo ----------
  const groundMat = new THREE.MeshStandardMaterial({ color: 0x0a0f0a, roughness: 1 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(420, 420, 1, 1), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(0, 0, -12);
  ground.receiveShadow = quality !== 'low';
  scene.add(ground);

  // ---------- Bosque: árboles instanciados ----------
  const trunkGeo = new THREE.CylinderGeometry(0.16, 0.32, 5.6, 6);
  trunkGeo.translate(0, 2.8, 0);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x151715, roughness: 0.95 });
  const canopyGeo = new THREE.ConeGeometry(1.7, 4.4, 7);
  canopyGeo.translate(0, 7.0, 0);
  const canopyMat = new THREE.MeshStandardMaterial({ color: 0x0d1a10, roughness: 1 });

  const TREE_COUNT = quality === 'low' ? 420 : quality === 'medium' ? 650 : 820;
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, TREE_COUNT);
  const canopies = new THREE.InstancedMesh(canopyGeo, canopyMat, TREE_COUNT);
  trunks.castShadow = quality === 'high';
  canopies.castShadow = quality === 'high';
  const dummy = new THREE.Object3D();
  let placed = 0;
  let guard = 0;
  while (placed < TREE_COUNT && guard++ < 4000) {
    const a = rand() * Math.PI * 2;
    const r = 12 + rand() * 176;
    const x = Math.cos(a) * r;
    const z = -12 + Math.sin(a) * r;
    // evitar spawn, casa, cobertizo y sendero principal
    if (Math.hypot(x, z - 46) < 8) continue;
    if (Math.abs(x - HOUSE.x) < 9 && Math.abs(z - HOUSE.z) < 8) continue;
    if (Math.abs(x) < 3.4 && z > -62 && z < 50) continue; // sendero
    if (Math.hypot(x - SHED.x, z - SHED.z) < 5) continue;
    const s = 0.85 + rand() * 1.15;
    dummy.position.set(x, 0, z);
    dummy.rotation.y = rand() * Math.PI * 2;
    dummy.scale.set(s, s * (0.9 + rand() * 0.3), s);
    dummy.updateMatrix();
    trunks.setMatrixAt(placed, dummy.matrix);
    // algunos árboles secos sin copa
    const bare = rand() < 0.3;
    dummy.scale.set(bare ? 0.0001 : s, bare ? 0.0001 : s * (0.8 + rand() * 0.4), bare ? 0.0001 : s);
    dummy.updateMatrix();
    canopies.setMatrixAt(placed, dummy.matrix);
    circleCols.push({ x, z, r: 0.38 * s, blocksLos: true });
    placed++;
  }
  trunks.count = placed; canopies.count = placed;
  trunks.instanceMatrix.needsUpdate = true; canopies.instanceMatrix.needsUpdate = true;
  scene.add(trunks); scene.add(canopies);

  // ---------- Rocas instanciadas (escondites) ----------
  const rockGeo = new THREE.DodecahedronGeometry(1, 0);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x23262b, roughness: 0.92, metalness: 0.05 });
  const ROCK_COUNT = quality === 'low' ? 90 : quality === 'medium' ? 140 : 180;
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, ROCK_COUNT);
  rocks.castShadow = quality === 'high';
  let rp = 0; guard = 0;
  while (rp < ROCK_COUNT && guard++ < 2000) {
    const a = rand() * Math.PI * 2;
    const r = 10 + rand() * 168;
    const x = Math.cos(a) * r;
    const z = -12 + Math.sin(a) * r;
    if (Math.abs(x - HOUSE.x) < 12 && Math.abs(z - HOUSE.z) < 10) continue;
    if (Math.abs(x) < 4.2 && z > -62 && z < 50) continue;
    if (Math.hypot(x, z - 46) < 7) continue;
    const big = rand() < 0.4;
    const s = big ? 1.5 + rand() * 1.1 : 0.55 + rand() * 0.6;
    dummy.position.set(x, s * 0.55, z);
    dummy.rotation.set(rand(), rand() * Math.PI, rand());
    dummy.scale.set(s, s * (0.8 + rand() * 0.5), s);
    dummy.updateMatrix();
    rocks.setMatrixAt(rp, dummy.matrix);
    circleCols.push({ x, z, r: s * (big ? 1.15 : 0.9), blocksLos: big });
    rp++;
  }
  rocks.count = rp; rocks.instanceMatrix.needsUpdate = true;
  scene.add(rocks);

  // ---------- Arbustos instanciados ----------
  const bushGeo = new THREE.IcosahedronGeometry(0.8, 0);
  const bushMat = new THREE.MeshStandardMaterial({ color: 0x0f2412, roughness: 1 });
  const BUSH_COUNT = quality === 'low' ? 150 : quality === 'medium' ? 220 : 280;
  const bushes = new THREE.InstancedMesh(bushGeo, bushMat, BUSH_COUNT);
  let bp = 0; guard = 0;
  while (bp < BUSH_COUNT && guard++ < 3000) {
    const a = rand() * Math.PI * 2;
    const r = 9 + rand() * 172;
    const x = Math.cos(a) * r;
    const z = -12 + Math.sin(a) * r;
    if (Math.abs(x - HOUSE.x) < 10 && Math.abs(z - HOUSE.z) < 8.5) continue;
    const s = 0.6 + rand() * 0.9;
    dummy.position.set(x, s * 0.4, z);
    dummy.rotation.set(rand(), rand() * Math.PI, 0);
    dummy.scale.set(s, s * 0.6, s);
    dummy.updateMatrix();
    bushes.setMatrixAt(bp, dummy.matrix);
    circleCols.push({ x, z, r: s * 0.75, blocksLos: false });
    bp++;
  }
  bushes.count = bp; bushes.instanceMatrix.needsUpdate = true;
  scene.add(bushes);

  // ---------- Muros ----------
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x1c1a17, roughness: 0.9 });
  const addWall = (x: number, z: number, w: number, d: number, h: number): void => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
    m.position.set(x, h / 2, z);
    m.castShadow = quality === 'high';
    m.receiveShadow = true;
    scene.add(m);
    boxCols.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, blocksLos: true });
  };

  // --- Casa familiar (entrada orientada a +z) ---
  const hx = HOUSE.x, hz = HOUSE.z, hw = HOUSE.w, hd = HOUSE.d, hh = HOUSE.h;
  const T = 0.3;
  // pared sur con hueco de puerta (gap x[-0.7, 0.7])
  const segW = (hw - 1.4) / 2;
  addWall(hx - 0.7 - segW / 2, hz + hd / 2, segW, T, hh);
  addWall(hx + 0.7 + segW / 2, hz + hd / 2, segW, T, hh);
  // pared norte
  addWall(hx, hz - hd / 2, hw, T, hh);
  // this oeste y este
  addWall(hx - hw / 2, hz, T, hd, hh);
  addWall(hx + hw / 2, hz, T, hd, hh);
  // divisor dormitorio este: x = hx+2.0, gap de puerta z[-63.4,-62.2]
  addWall(hx + 2.0, hz - hd / 2 + 0.85, T, 1.7, hh);
  addWall(hx + 2.0, hz + 1.05, T, hd / 2 - 1.05, hh);
  // techo
  const roof = new THREE.Mesh(new THREE.BoxGeometry(hw + 0.8, 0.25, hd + 0.8), wallMat);
  roof.position.set(hx, hh + 0.12, hz);
  scene.add(roof);

  // luz interior cálida
  const houseLight = new THREE.PointLight(0xffb469, 1.2, 12, 1.8);
  houseLight.position.set(hx - 2, hh - 0.4, hz + 1);
  scene.add(houseLight);

  // marco de la puerta
  const doorFrameMat = new THREE.MeshStandardMaterial({ color: 0x241a10, roughness: 0.85 });
  const frameLeft = new THREE.Mesh(new THREE.BoxGeometry(0.16, 2.4, 0.38), doorFrameMat);
  const frameRight = frameLeft.clone();
  const frameTop = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.18, 0.38), doorFrameMat);
  frameLeft.position.set(hx - 0.79, 1.2, hz + hd / 2 + 0.01);
  frameRight.position.set(hx + 0.79, 1.2, hz + hd / 2 + 0.01);
  frameTop.position.set(hx, 2.31, hz + hd / 2 + 0.01);
  scene.add(frameLeft, frameRight, frameTop);
  // Puerta principal con bisagras y pomo; el hueco de la pared queda cubierto.
  const doorPivot = new THREE.Group();
  doorPivot.position.set(hx - 0.72, 0, hz + hd / 2 + 0.08);
  const doorPanel = new THREE.Mesh(new THREE.BoxGeometry(1.34, 2.18, 0.12), new THREE.MeshStandardMaterial({ color: 0x38271a, roughness: 0.82 }));
  doorPanel.position.set(0.67, 1.09, 0);
  doorPanel.castShadow = true;
  const doorInset = new THREE.Mesh(new THREE.BoxGeometry(1.04, 1.72, 0.035), new THREE.MeshStandardMaterial({ color: 0x24180f, roughness: 0.9 }));
  doorInset.position.set(0.67, 1.12, 0.075);
  const doorKnob = new THREE.Mesh(new THREE.SphereGeometry(0.055, 12, 10), new THREE.MeshStandardMaterial({ color: 0x9b8051, metalness: 0.72, roughness: 0.3 }));
  doorKnob.position.set(1.19, 1.02, 0.11);
  doorPivot.add(doorPanel, doorInset, doorKnob);
  scene.add(doorPivot);
  const bedroomDoor = new THREE.Group();
  bedroomDoor.position.set(hx + 2.0, 0, hz + 3.7);
  const bedroomPanel = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.12, 1.15), new THREE.MeshStandardMaterial({ color: 0x302116, roughness: 0.86 }));
  bedroomPanel.position.set(0, 1.06, 0.575);
  const bedroomKnob = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8), new THREE.MeshStandardMaterial({ color: 0x92794c, metalness: 0.65 }));
  bedroomKnob.position.set(0.08, 1.0, 0.98);
  bedroomDoor.add(bedroomPanel, bedroomKnob);
  scene.add(bedroomDoor);

  // ---------- Mobiliario ----------
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x2a1f14, roughness: 0.85 });
  const addFurniture = (x: number, y: number, z: number, w: number, h: number, d: number, mat: THREE.Material = woodMat, collide = true): THREE.Mesh => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    m.castShadow = true;
    m.receiveShadow = true;
    scene.add(m);
    if (collide) boxCols.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, blocksLos: false });
    return m;
  };

  // sofá, mesa
  addFurniture(hx - 3.4, 0.45, hz + 0.6, 2.1, 0.9, 0.9);
  addFurniture(hx - 1.9, 0.4, hz - 2.2, 1.4, 0.8, 1.4);
  // televisor antiguo sobre mueble
  addFurniture(hx - 3.4, 0.4, hz - 3.6, 1.4, 0.8, 0.7);
  const tvBody = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.85, 0.6), new THREE.MeshStandardMaterial({ color: 0x111114, roughness: 0.5 }));
  tvBody.position.set(hx - 3.4, 1.25, hz - 3.6);
  scene.add(tvBody);
  const tvCanvas = document.createElement('canvas');
  tvCanvas.width = 128; tvCanvas.height = 96;
  const tvCtx = tvCanvas.getContext('2d')!;
  const tvCanvasTexture = new THREE.CanvasTexture(tvCanvas);
  const tvScreen = new THREE.Mesh(new THREE.PlaneGeometry(0.85, 0.6), new THREE.MeshBasicMaterial({ map: tvCanvasTexture }));
  tvScreen.position.set(hx - 3.4, 1.27, hz - 3.28);
  scene.add(tvScreen);
  // estantería con grabadora 3 (pasillo norte-oeste)
  addFurniture(hx - 2.5, 0.65, hz - 3.6, 0.8, 1.3, 0.55);
  // lámpara de pie
  const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.16, 1.6, 8), new THREE.MeshStandardMaterial({ color: 0x3a2f1d }));
  lamp.position.set(hx - 0.6, 0.8, hz - 3.8);
  scene.add(lamp);

  // --- Dormitorio (este): cama en x[hx+3, hx+5], armario en pared norte ---
  const bedFrame = addFurniture(hx + 3.9, 0.3, hz - 2.6, 1.7, 0.6, 2.4, new THREE.MeshStandardMaterial({ color: 0x241612, roughness: 0.9 }));
  const mattress = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.22, 2.2), new THREE.MeshStandardMaterial({ color: 0x3d3d3a, roughness: 1 }));
  mattress.position.set(hx + 3.9, 0.66, hz - 2.6);
  scene.add(mattress);
  bedFrame.receiveShadow = true;
  // mesita
  addFurniture(hx + 2.9, 0.35, hz - 0.9, 0.7, 0.7, 0.7);

  // ARMARIO de madera en la pared norte del dormitorio
  const closetGroup = new THREE.Group();
  const closetMat = new THREE.MeshStandardMaterial({ color: 0x1f150d, roughness: 0.9 });
  const closetShell = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.6, 0.75), closetMat);
  closetShell.castShadow = true;
  closetGroup.add(closetShell);
  // hueco frontal oscuro
  const hole = new THREE.Mesh(
    new THREE.PlaneGeometry(1.15, 2.3),
    new THREE.MeshBasicMaterial({ color: 0x000000 })
  );
  hole.position.set(0, -0.05, 0.385);
  closetGroup.add(hole);
  // puerta pivotante (bisagra en el borde izquierdo)
  const closetDoor = new THREE.Group();
  const doorMesh = new THREE.Mesh(
    new THREE.BoxGeometry(1.15, 2.4, 0.06),
    new THREE.MeshStandardMaterial({ color: 0x2c1d11, roughness: 0.85 })
  );
  doorMesh.position.set(0.575, 0, 0.02);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), new THREE.MeshStandardMaterial({ color: 0x6b5b3e, metalness: 0.7 }));
  knob.position.set(1.05, 0, 0.06);
  closetDoor.add(doorMesh); closetDoor.add(knob);
  closetDoor.position.set(-0.575, 0, 0.42);
  closetGroup.add(closetDoor);
  closetGroup.position.set(hx + 3.15, 1.3, hz - hd / 2 + 0.72);
  scene.add(closetGroup);
  boxCols.push({
    minX: hx + 3.15 - 0.75, maxX: hx + 3.15 + 0.75,
    minZ: hz - hd / 2 + 0.72 - 0.35, maxZ: hz - hd / 2 + 0.72 + 0.35,
    blocksLos: true,
  });

  // --- Grabadoras portátiles y casetes ---
  const radioMeshes: any = {};
  const radioLights: any = {};
  // Seis puntos separados por sectores; ninguna grabación comparte el área de otra.
  const radioPositions = [
    new THREE.Vector3(26,1.05,-16),
    new THREE.Vector3(-38,1.0,-34),
    new THREE.Vector3(48,1.0,38),
    new THREE.Vector3(-13,1.0,-30),
    new THREE.Vector3(72,1.0,-70),
    new THREE.Vector3(-31,1.0,28),
  ];
  radioPositions.forEach((pos, i) => {
    const id = `radio${i+1}`;
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.28,0.18,0.18), new THREE.MeshStandardMaterial({color:0x191b1d,roughness:0.8}));
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.008,0.008,0.28,6), new THREE.MeshStandardMaterial({color:0x55585a,metalness:0.6}));
    antenna.position.set(0.07,0.2,0);
    g.add(body,antenna); g.position.copy(pos); scene.add(g);
    radioMeshes[id]=g;
    const pl = new THREE.PointLight(0x9bb6ff,0.6,5); pl.position.copy(pos); scene.add(pl); radioLights[id]=pl;
  });

  const interactables: any[] = [
    ...radioPositions.map((p,i)=>({id:`radio${i+1}`,label:`ESCUCHAR GRABACIÓN ${i+1}`,x:p.x,y:p.y,z:p.z,radius:2.0})),
    { id: 'cama', label: 'DORMIR', x: hx + 3.9, y: 0.75, z: hz - 2.6, radius: 2.2 },
  ];

  const zones: ZoneDef[] = [
    { id: 'sendero', name: 'SENDERO OLVIDADO', x: 0, z: 20, r: 6, pts: 120 },
    { id: 'claro', name: 'CLARO DE LAS ROCAS', x: -34, z: 24, r: 9, pts: 180 },
    { id: 'cobertizo', name: 'COBERTIZO ABANDONADO', x: SHED.x, z: SHED.z, r: 6, pts: 220 },
    { id: 'circulo', name: 'CÍRCULO DE ÁRBOLES SECOS', x: 34, z: 12, r: 9, pts: 200 },
    { id: 'casa', name: 'LA CASA FAMILIAR', x: hx, z: hz + hd / 2 + 3, r: 7, pts: 300 },
    { id: 'dormitorio', name: 'EL DORMITORIO', x: hx + 3.6, z: hz - 2.4, r: 3.4, pts: 250 },
  ];

  // ---------- Puntos de aparición de monstruos ----------
  const spawnsA = [new THREE.Vector3(14, 0, 30), new THREE.Vector3(-24, 0, 20), new THREE.Vector3(-10, 0, 6), new THREE.Vector3(20, 0, -34), new THREE.Vector3(92, 0, 74), new THREE.Vector3(-118, 0, 52)];
  const spawnsR = [new THREE.Vector3(8, 0, 22), new THREE.Vector3(-16, 0, 8), new THREE.Vector3(14, 0, -4), new THREE.Vector3(-28, 0, -8), new THREE.Vector3(-105, 0, -82), new THREE.Vector3(126, 0, -46)];
  const spawnsD = [new THREE.Vector3(-20, 0, 28), new THREE.Vector3(12, 0, 36), new THREE.Vector3(-34, 0, 2), new THREE.Vector3(6, 0, -40), new THREE.Vector3(74, 0, -122), new THREE.Vector3(-142, 0, 104)];

  return {
    scene,
    circleCols,
    boxCols,
    interactables,
    zones,
    radioMeshes,
    radioLights,
    closetGroup,
    closetDoor,
    bedPos: new THREE.Vector3(hx + 3.9, 1.1, hz - 2.6),
    bedroomPos: new THREE.Vector3(hx + 3.6, 1.2, hz - 2.4),
    houseDoorPos: new THREE.Vector3(hx, 1.2, hz + hd / 2 + 1.2),
    houseDoor: doorPivot,
    bedroomDoor,
    monsterSpawns: { alto: spawnsA, rastrero: spawnsR, deforme: spawnsD },
    tvCanvasTexture,
    tvCtx,
    houseLight,
    electricFence,
  };
}
